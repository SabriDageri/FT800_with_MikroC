#include "Demo_1_objects.h"
#include "Demo_1_resources.h"
#include "built_in.h"
#include "FT800_Types.h"


// TFT module connections
sbit FT800_RST at LATE1_bit;
sbit FT800_CS at LATE0_bit;
sbit FT800_RST_Direction at TRISE1_bit;
sbit FT800_CS_Direction at TRISE0_bit;
// End TFT module connections

// Object type constants
// Usage: VTFT stack internally
const VTFT_OT_LABEL      = 4;
const VTFT_OT_EVECLOCK   = 24;
const VTFT_OT_EVEGAUGE   = 25;
const VTFT_OT_EVEKEYS    = 27;
const VTFT_OT_EVESLIDER  = 32;
const VTFT_OT_EVESKETCH  = 35;
const VTFT_OT_EVEBUTTON  = 36;
const VTFT_OT_EVENUMBER  = 42;
// ~Object type constants

// Event type constants
// Usage: OnEvent
const VTFT_EVT_UP    = 0;
const VTFT_EVT_DOWN  = 1;
const VTFT_EVT_CLICK = 2;
const VTFT_EVT_PRESS = 3;
// ~Event type constants

// Sound action constants
// Usage: sound event action property and ProcessEvent
const VTFT_SNDACT_NONE  = 0;
const VTFT_SNDACT_PLAY  = 1;
const VTFT_SNDACT_STOP  = 2;
// ~Sound action constants

// Resource loading constants.
// Usage: DrawScreenO and LoadCurrentScreenResToGRAM
const VTFT_LOAD_RES_NONE    = 0x00; // do not load g-ram resources
const VTFT_LOAD_RES_STATIC  = 0x01; // load g-ram resources for static objects
const VTFT_LOAD_RES_DYNAMIC = 0x02; // load g-ram resources for dynamic objects
const VTFT_LOAD_RES_ALL     = 0x03; // load g-ram resources for all objects
// ~Resource loading constants

// Display effect constants
// Usage: DrawScreenO
const VTFT_DISPLAY_EFF_NONE         = 0x00; // no effect when switching between screens
const VTFT_DISPLAY_EFF_LIGHTS_FADE  = 0x04; // backlight: fade out before, fade in after drawing new screen
const VTFT_DISPLAY_EFF_LIGHTS_OFF   = 0x08; // backlight: turn off before, turn on after drawing new screen
// ~Display effect constants

// Stack flags
// Usage: internally used by VTFT stack
const VTFT_INT_REPAINT_ON_DOWN     = 1 << 0;
const VTFT_INT_REPAINT_ON_UP       = 1 << 1;
const VTFT_INT_BRING_TO_FRONT      = 1 << 2;
const VTFT_INT_INTRINSIC_CLICK_EFF = 1 << 3;
// ~Stack flags

// Table of object draw handlers
// Use object type constants to access coresponding object draw handler
const TPointer DrawHandlerTable[44] = {
  0,               // Button draw handler not used
  0,               // CButton draw handler not used
  0,               // ButtonRound draw handler not used
  0,               // CButtonRound draw handler not used
  &DrawLabel,      // Label draw handler
  0,               // CLabel draw handler not used
  0,               // Image draw handler not used
  0,               // CImage draw handler not used
  0,               // Circle draw handler not used
  0,               // CCircle draw handler not used
  0,               // CircleButton draw handler not used
  0,               // CCircleButton draw handler not used
  0,               // Box draw handler not used
  0,               // CBox draw handler not used
  0,               // BoxRound draw handler not used
  0,               // CBoxRound draw handler not used
  0,               // Line draw handler not used
  0,               // CLine draw handler not used
  0,               // Polygon draw handler not used
  0,               // CPolygon draw handler not used
  0,               // CheckBox draw handler not used
  0,               // RadioButton draw handler not used
  0,               // ProgressBar draw handler not used
  0,               // Audio draw handler not used
  &DrawEveClock,   // EveClock draw handler
  &DrawEveGauge,   // EveGauge draw handler
  0,               // EveDial draw handler not used
  &DrawEveKeys,    // EveKeys draw handler
  0,               // CEveKeys draw handler not used
  0,               // EveProgressBar draw handler not used
  0,               // EveScrollBar draw handler not used
  0,               // EveToggle draw handler not used
  &DrawEveSlider,  // EveSlider draw handler
  &DrawEveSpinner, // EveSpinner draw handler
  0,               // EveScreenSaver draw handler not used
  &DrawEveSketch,  // EveSketch draw handler
  &DrawEveButton,  // EveButton draw handler
  0,               // CEveButton draw handler not used
  0,               // EveGradient draw handler not used
  0,               // CEveGradient draw handler not used
  0,               // EveText draw handler not used
  0,               // CEveText draw handler not used
  &DrawEveNumber,  // EveNumber draw handler
  0                // CEveNumber draw handler not used
};
// ~Table of draw handler pointers

// Table of animations
void *ScreensEveAnimationTable[4] = {
  &EveSpinner1,
  0,
  0,
  &EveSketch1
};
// ~Table of animations


// Default configuration parameters
const TFT800Display VTFT_FT800_CONFIG_DISPLAY =
{
  48000000,        // Frequency          = main clock frequency
  0,               // OutRenderMode      = 0 normal, 1 write, 2 read
  0,               // RenderReadScanLine = scanline for read render mode
  0,               // RenderWriteTrigger = trigger for write render mode (read only)
  525,             // hCycle             = number if horizontal cycles for display
  40,              // hOffset            = horizontal offset from starting signal
  480,             // hSize              = width resolution
  0,               // hSync0             = hsync falls
  41,              // hSync1             = hsync rise
  286,             // vCycle             = number of vertical cycles for display
  8,               // vOffset            = vertical offset from start signal
  272,             // vSize              = height resolution
  0,               // vSync0             = vsync falls
  10,              // vSync1             = vsync rise
  0,               // Rotate             = rotate display
  0x01B6,          // OutBits            = output bits resolution
  0,               // OutDither          = output number of bits
  0x0000,          // OutSwizzle         = output swizzle
  0,               // OutCSpread         = output clock spread enable
  1,               // PClockPolarity     = clock polarity: 0 - rising edge, 1 - falling edge
  5,               // PClock             = clock prescaler of FT800: - 0 means disable and >0 means 48MHz/pclock
};

const TFT800Touch VTFT_FT800_CONFIG_TOUCH =
{
  3,               // TouchMode        = touch screen mode (2 bits): 0 - off, 1 - oneshot, 2 - frame, 3 - continuous
  1,               // TouchADCMode     = touch screen adc mode (1 bit): 0 - singleended, 1 - differential
  8000,            // TouchCharge      = Touchscreen charge time, units of 6 clocks
  15,              // TouchSettle      = touch screen settle time - 4 bits
  15,              // TouchOversample  = touch screen oversample - 4 bits
  2000,            // TouchRZThreshold = Touchscreen resistance threshold
};

const TFT800GPIO VTFT_FT800_CONFIG_GPIO =
{
  0xFC,            // GPIODIR = GPIO direction: 1 - output, 0 - input (8bit wide)
  0xFF,            // GPIO    = GPIO data latch
};

const TFT800PWM VTFT_FT800_CONFIG_PWM =
{
  1000,            // Freq = PWM frequency - 14 bits
  128,             // Duty = PWM duty cycle, 0 to 128 is the range
};

const TFT800Interrupt VTFT_FT800_CONFIG_INTERRUPT =
{
  0,               // Flags  = interrupt flags (read only)
  0,               // Enable = global interrupt enable: 1 - enabled, 0 - disabled
  255,             // Mask   = interrupt mask value (individual interrupt enable): 1 - masked/disabled, 0 - enabled
};

const TFT800Sound VTFT_FT800_CONFIG_SOUND =
{
  0,               // Volume
  {0,              // Effect
  0},              // Pitch
  0,               // Play
};

const TFT800Audio VTFT_FT800_CONFIG_AUDIO =
{
  0,               // Volume
  0,               // StartAddress
  0,               // Length
  0,               // ReadPtr
  8000,            // Frequency
  0,               // Format
  0,               // Loop = audio playback mode
  0,               // Play
};

// Global variables

TTouchStat TouchS = {0};


/////////////////////////
TScreen *CurrentScreen = 0;


TScreen Screen1;

TEveClock   EveClock1;
TEvent      EveClock1_OnPress;
TEveButton  EveButton1;
TEvent      EveButton1_OnDown;
TEvent      EveButton1_OnPress;
char        EveButton1_Caption[5] = "NEXT";
TEveNumber  EveNumber2;
TEveNumber  EveNumber3;
TEveNumber  EveNumber4;
TEveGauge   EveGauge1;
TEvent      EveGauge1_OnUp;
TEvent      EveGauge1_OnDown;
TLabel      Label2;
char        Label2_Caption[6] = "CLOCK";
TLabel      Label3;
char        Label3_Caption[12] = "TEMPERATURE";
TEveNumber  EveNumber10;
TLabel      Label4;
char        Label4_Caption[2] = "C";
TLabel      Label5;
char        Label5_Caption[2] = "-";
TEveSpinner EveSpinner1;

TLabel *const code Screen1_Labels[4] = {
  &Label2,              
  &Label3,              
  &Label4,              
  &Label5               
};

TEveClock *const code Screen1_EveClocks[1] = {
  &EveClock1            
};

TEveGauge *const code Screen1_EveGauges[1] = {
  &EveGauge1            
};

TEveSpinner *const code Screen1_EveSpinners[1] = {
  &EveSpinner1          
};

TEveButton *const code Screen1_EveButtons[1] = {
  &EveButton1           
};

TEveNumber *const code Screen1_EveNumbers[4] = {
  &EveNumber2,          
  &EveNumber3,          
  &EveNumber4,          
  &EveNumber10          
};


TScreen Screen2;

TLabel     Label1;
char       Label1_Caption[15] = "Clock Settings";
TEveButton EveButton4;
TEvent     EveButton4_OnDown;
TEvent     EveButton4_OnPress;
char       EveButton4_Caption[7] = "Minute";
TEveButton EveButton5;
TEvent     EveButton5_OnDown;
TEvent     EveButton5_OnPress;
char       EveButton5_Caption[5] = "Hour";
TEveButton EveButton6;
TEvent     EveButton6_OnDown;
TEvent     EveButton6_OnPress;
char       EveButton6_Caption[5] = "Year";
TEveButton EveButton7;
TEvent     EveButton7_OnDown;
TEvent     EveButton7_OnPress;
char       EveButton7_Caption[6] = "Mount";
TEveButton EveButton8;
TEvent     EveButton8_OnDown;
TEvent     EveButton8_OnPress;
char       EveButton8_Caption[4] = "Day";
TEveKeys   EveKeys1;
TEvent     EveKeys1_OnDown;
TEvent     EveKeys1_OnPress;
char       EveKeys1_Caption[11] = "0123456789";
TEveNumber EveNumber5;
TEveNumber EveNumber6;
TEveNumber EveNumber7;
TEveNumber EveNumber8;
TEveNumber EveNumber9;
TEveButton EveButton11;
TEvent     EveButton11_OnDown;
TEvent     EveButton11_OnPress;
char       EveButton11_Caption[5] = "Save";
TEveButton EveButton9;
TEvent     EveButton9_OnDown;
TEvent     EveButton9_OnPress;
char       EveButton9_Caption[5] = "NEXT";
TEveButton EveButton10;
TEvent     EveButton10_OnDown;
TEvent     EveButton10_OnPress;
char       EveButton10_Caption[5] = "BACK";

TLabel *const code Screen2_Labels[1] = {
  &Label1               
};

TEveKeys *const code Screen2_EveKeys[1] = {
  &EveKeys1             
};

TEveButton *const code Screen2_EveButtons[8] = {
  &EveButton4,          
  &EveButton5,          
  &EveButton6,          
  &EveButton7,          
  &EveButton8,          
  &EveButton11,         
  &EveButton9,          
  &EveButton10          
};

TEveNumber *const code Screen2_EveNumbers[5] = {
  &EveNumber5,          
  &EveNumber6,          
  &EveNumber7,          
  &EveNumber8,          
  &EveNumber9           
};


TScreen Screen3;

TEveSlider EveSlider1;
TEvent     EveSlider1_OnPress;
TEveSlider EveSlider2;
TEvent     EveSlider2_OnPress;
TEveSlider EveSlider3;
TEvent     EveSlider3_OnPress;
TEveNumber EveNumber1;
TEveButton EveButton12;
TEvent     EveButton12_OnDown;
TEvent     EveButton12_OnPress;
char       EveButton12_Caption[5] = "NEXT";
TEveButton EveButton13;
TEvent     EveButton13_OnDown;
TEvent     EveButton13_OnPress;
char       EveButton13_Caption[5] = "BACK";

TEveSlider *const code Screen3_EveSliders[3] = {
  &EveSlider1,          
  &EveSlider2,          
  &EveSlider3           
};

TEveButton *const code Screen3_EveButtons[2] = {
  &EveButton12,         
  &EveButton13          
};

TEveNumber *const code Screen3_EveNumbers[1] = {
  &EveNumber1           
};


TScreen Screen4;

TEveSketch EveSketch1;
TEvent     EveSketch1_OnDown;
TEveButton EveButton2;
TEvent     EveButton2_OnDown;
TEvent     EveButton2_OnPress;
char       EveButton2_Caption[5] = "NEXT";
TEveButton EveButton3;
TEvent     EveButton3_OnDown;
TEvent     EveButton3_OnPress;
char       EveButton3_Caption[6] = "Clear";
TEveButton EveButton14;
TEvent     EveButton14_OnDown;
TEvent     EveButton14_OnPress;
char       EveButton14_Caption[5] = "BACK";

TEveSketch *const code Screen4_EveSketches[1] = {
  &EveSketch1           
};

TEveButton *const code Screen4_EveButtons[3] = {
  &EveButton2,          
  &EveButton3,          
  &EveButton14          
};


static char IsInsideObject(TObjInfo *AObjInfo, unsigned int X, unsigned int Y) {
  TRect  *ptrPressRect = 0;
  TRect  *ptrPressCircle = 0;

  if ((AObjInfo->HitX == X) && (AObjInfo->HitY == Y))
    return 1;

  switch (AObjInfo->Type) {
    // Label
    case VTFT_OT_LABEL: {
      ptrPressRect = (TRect *)&(((TLabel *)AObjInfo->Obj)->Left);
      break;
    }
    // EveClock
    case VTFT_OT_EVECLOCK: {
      ptrPressCircle = (TRect *)&(((TEveClock *)AObjInfo->Obj)->Left);
      break;
    }
    // EveGauge
    case VTFT_OT_EVEGAUGE: {
      ptrPressCircle = (TRect *)&(((TEveGauge *)AObjInfo->Obj)->Left);
      break;
    }
    // EveKeys
    case VTFT_OT_EVEKEYS: {
      ptrPressRect = (TRect *)&(((TEveKeys *)AObjInfo->Obj)->Left);
      break;
    }
    // EveSlider
    case VTFT_OT_EVESLIDER: {
      ptrPressRect = (TRect *)&(((TEveSlider *)AObjInfo->Obj)->Left);
      break;
    }
    // EveSketch
    case VTFT_OT_EVESKETCH: {
      ptrPressRect = (TRect *)&(((TEveSketch *)AObjInfo->Obj)->Left);
      break;
    }
    // EveButton
    case VTFT_OT_EVEBUTTON: {
      ptrPressRect = (TRect *)&(((TEveButton *)AObjInfo->Obj)->Left);
      break;
    }
    // EveNumber
    case VTFT_OT_EVENUMBER: {
      ptrPressRect = (TRect *)&(((TEveNumber *)AObjInfo->Obj)->Left);
      break;
    }
  }

  if (ptrPressRect) {
    if ((ptrPressRect->Left <= X) && (ptrPressRect->Left+ptrPressRect->Width-1 >= X) &&
        (ptrPressRect->Top  <= Y) && (ptrPressRect->Top+ptrPressRect->Height-1 >= Y))
      return 1;
  }
  else if (ptrPressCircle) {
    if ((ptrPressCircle->Left <= X) && (ptrPressCircle->Left+ptrPressCircle->Width*2-1 >= X) &&
        (ptrPressCircle->Top  <= Y) && (ptrPressCircle->Top+ptrPressCircle->Width*2-1 >= Y))
      return 1;
  }

  return 0;
}

void DrawLabel(TLabel *ALabel) {
  if (ALabel->Visible) {
    if (ALabel->FontHandle >= 16)
      FT800_Canvas_FontSystem(ALabel->FontHandle, ALabel->Font_Color, ALabel->Opacity);
    else
      FT800_Canvas_Font(ALabel->FontHandle, ALabel->FontName, ALabel->Source, ALabel->Font_Color, ALabel->Opacity);

    if (ALabel->Tag)
      FT800_Canvas_Tag(ALabel->Tag);

    FT800_Screen_TextPos(ALabel->Left, ALabel->Top, ALabel->Caption);
  }
}

void DrawEveClock(TEveClock *AEveClock) {
  unsigned long drawOptions;
  
  if (AEveClock->Visible) {
    if ((VTFT_OT_EVECLOCK == TouchS.ActObjInfo.Type) && (AEveClock == (TEveClock *)TouchS.ActObjInfo.Obj))
      FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, AEveClock->Press_Color, AEveClock->Opacity);
    else 
      FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, AEveClock->Color, AEveClock->Opacity);

    FT800_Canvas_Pen(AEveClock->Pen_Width, AEveClock->Pen_Color, AEveClock->Opacity);

    FT800_Canvas_CPGraphics_Time(AEveClock->Hour, AEveClock->Min, AEveClock->Sec, 0);

    if (AEveClock->Tag)
      FT800_Canvas_Tag(AEveClock->Tag);

    drawOptions = 0;
    if (AEveClock->Flat)
      drawOptions |= _FT800_CP_DRAW_OPT_FLAT;
    if (AEveClock->NoBackground)
      drawOptions |= _FT800_CP_DRAW_OPT_NOBACK;
    if (!AEveClock->TicksVisible)
      drawOptions |= _FT800_CP_DRAW_OPT_NOTICKS;
    if (!AEveClock->HandsVisible)
      drawOptions |= _FT800_CP_DRAW_OPT_NOHANDS;
    if (!AEveClock->SecsVisible)
      drawOptions |= _FT800_CP_DRAW_OPT_NOSECS;
    FT800_Canvas_CPGraphics_DrawingOptions(drawOptions);

    FT800_Screen_ClockCp(AEveClock->Left+AEveClock->Radius, 
                       AEveClock->Top+AEveClock->Radius, 
                       AEveClock->Radius);
  }
}

void DrawEveGauge(TEveGauge *AEveGauge) {
  unsigned long drawOptions;
  
  if (AEveGauge->Visible) {
    if ((VTFT_OT_EVEGAUGE == TouchS.ActObjInfo.Type) && (AEveGauge == (TEveGauge *)TouchS.ActObjInfo.Obj))
      FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, AEveGauge->Press_Color, AEveGauge->Opacity);
    else 
      FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, AEveGauge->Color, AEveGauge->Opacity);

    FT800_Canvas_Pen(AEveGauge->Pen_Width, AEveGauge->Pen_Color, AEveGauge->Opacity);

    FT800_Canvas_CPGraphics_Major(AEveGauge->Major);
    FT800_Canvas_CPGraphics_Minor(AEveGauge->Minor);

    FT800_Canvas_CPGraphics_Range(AEveGauge->Range);

    FT800_Canvas_CPGraphics_Value(AEveGauge->Value);

    if (AEveGauge->Tag)
      FT800_Canvas_Tag(AEveGauge->Tag);

    drawOptions = 0;
    if (AEveGauge->Flat)
      drawOptions |= _FT800_CP_DRAW_OPT_FLAT;
    if (AEveGauge->NoBackground)
      drawOptions |= _FT800_CP_DRAW_OPT_NOBACK;
    if (!AEveGauge->TicksVisible)
      drawOptions |= _FT800_CP_DRAW_OPT_NOTICKS;
    if (AEveGauge->NoPointer)
      drawOptions |= _FT800_CP_DRAW_OPT_NOPTR;
    FT800_Canvas_CPGraphics_DrawingOptions(drawOptions);

    FT800_Screen_GaugeCp(AEveGauge->Left+AEveGauge->Radius, 
                       AEveGauge->Top+AEveGauge->Radius, 
                       AEveGauge->Radius);
  }
}

void DrawEveSlider(TEveSlider *AEveSlider) {
  unsigned long drawOptions;
  
  if (AEveSlider->Visible) {
    if ((VTFT_OT_EVESLIDER == TouchS.ActObjInfo.Type) && (AEveSlider == (TEveSlider *)TouchS.ActObjInfo.Obj))
      FT800_Canvas_BrushDualColor(_FT800_BRUSH_STYLE_SOLID, AEveSlider->Press_Color, AEveSlider->Thumb_Color, AEveSlider->Opacity);
    else 
      FT800_Canvas_BrushDualColor(_FT800_BRUSH_STYLE_SOLID, AEveSlider->Background_Color, AEveSlider->Thumb_Color, AEveSlider->Opacity);

    FT800_Canvas_Pen(1, AEveSlider->Color, AEveSlider->Opacity);

    FT800_Canvas_CPGraphics_Range(AEveSlider->Range);

    FT800_Canvas_CPGraphics_Value(AEveSlider->Value);

    if (AEveSlider->Tag)
      FT800_Canvas_Tag(AEveSlider->Tag);

    drawOptions = 0;
    if (AEveSlider->Flat)
      drawOptions |= _FT800_CP_DRAW_OPT_FLAT;
    FT800_Canvas_CPGraphics_DrawingOptions(drawOptions);

    FT800_Screen_SliderCP(AEveSlider->Left, AEveSlider->Top, AEveSlider->Width, AEveSlider->Height);
  }
}

void DrawEveKeys(TEveKeys *AEveKeys) {
  unsigned long drawOptions;
  
  if (AEveKeys->Visible) {
    FT800_Canvas_Brush(_FT800_BRUSH_STYLE_SOLID, _FT800_BRUSH_GR_BOTTOM_TO_TOP, AEveKeys->Color, AEveKeys->ColorTo, AEveKeys->Press_Color, AEveKeys->Opacity);

    if (AEveKeys->FontHandle >= 16)
      FT800_Canvas_FontSystem(AEveKeys->FontHandle, AEveKeys->Font_Color, AEveKeys->Opacity);
    else
      FT800_Canvas_Font(AEveKeys->FontHandle, AEveKeys->FontName, AEveKeys->Source, AEveKeys->Font_Color, AEveKeys->Opacity);

    if (AEveKeys->Tag)
      FT800_Canvas_Tag(AEveKeys->Tag);

    drawOptions = 0;
    if (AEveKeys->Flat)
      drawOptions |= _FT800_CP_DRAW_OPT_FLAT;
    if ((VTFT_OT_EVEKEYS == TouchS.ActObjInfo.Type) && (AEveKeys == (TEveKeys *)TouchS.ActObjInfo.Obj))
      drawOptions |= TouchS.Tag;
    if (AEveKeys->AutoSize)
      drawOptions |= _FT800_CP_DRAW_OPT_CENTER;
    FT800_Canvas_CPGraphics_DrawingOptions(drawOptions);

    FT800_Screen_KeysCP(AEveKeys->Left, AEveKeys->Top, AEveKeys->Width, AEveKeys->Height, AEveKeys->Caption);
  }
}

char DrawEveSpinner(TEveSpinner *AEveSpinner) {
  if(*CurrentScreen->EveAnimation == (unsigned short*)AEveSpinner) {
    if (AEveSpinner->Tag)
      FT800_Canvas_Tag(AEveSpinner->Tag);

    FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, AEveSpinner->Color, 255);

    FT800_Canvas_CPGraphics_Spinner(AEveSpinner->Style, AEveSpinner->Scale);
    FT800_Screen_SpinnerCP(AEveSpinner->Left, AEveSpinner->Top);
    return 1;
  }
  return 0;
}

void GetEveSketchBmpCfg(TEveSketch *AEveSketch, int *xPos, int *yPos, TFT800BmpConfig *bmpCfg) {
  unsigned int tmpPenW;

  tmpPenW = (AEveSketch->Pen_Width / 2) + 1;

  if(xPos != 0) {
    *xPos = AEveSketch->Left + tmpPenW;
  }
  if(yPos != 0) {
    *yPos = AEveSketch->Top + tmpPenW;
  }

  if(bmpCfg != 0) {
    FT800_Canvas_BmpParamsToCfg(AEveSketch->Source, AEveSketch->Width - (2 * tmpPenW), AEveSketch->Height - (2 * tmpPenW), AEveSketch->ColorFormat, bmpCfg);
  }
}

void DrawEveSketch(TEveSketch *AEveSketch) {
  TFT800BmpConfig bmpCfg;
  int sketchBmpX, sketchBmpY;
  
  GetEveSketchBmpCfg(AEveSketch, &sketchBmpX, &sketchBmpY, &bmpCfg);

  if(AEveSketch->Clear != 0) {
    FT800_CP_CmdMemZero(AEveSketch->Source, (unsigned long)bmpCfg.Layout.LineStride * bmpCfg.Layout.Height);
  }

  if(AEveSketch->Visible != 0) {
    if (AEveSketch->Tag)
      FT800_Canvas_Tag(AEveSketch->Tag);

    if(AEveSketch->Transparent == 0) {
      FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, AEveSketch->Background_Color, AEveSketch->Opacity);
      FT800_Canvas_Pen(AEveSketch->Pen_Width, AEveSketch->Pen_Color, AEveSketch->Opacity);
      FT800_Screen_Box(AEveSketch->Left, AEveSketch->Top, AEveSketch->Left + AEveSketch->Width - 1, AEveSketch->Top + AEveSketch->Height-1);
    }
    else if(AEveSketch->Pen_Width > 0) {
      FT800_Canvas_Pen(AEveSketch->Pen_Width, AEveSketch->Pen_Color, AEveSketch->Opacity);
      FT800_Screen_Line(AEveSketch->Left, AEveSketch->Top, AEveSketch->Left + AEveSketch->Width, AEveSketch->Top);
      FT800_Screen_Line(AEveSketch->Left + AEveSketch->Width, AEveSketch->Top, AEveSketch->Left + AEveSketch->Width, AEveSketch->Top + AEveSketch->Height);
      FT800_Screen_Line(AEveSketch->Left, AEveSketch->Top + AEveSketch->Height, AEveSketch->Left + AEveSketch->Width, AEveSketch->Top + AEveSketch->Height);
      FT800_Screen_Line(AEveSketch->Left, AEveSketch->Top, AEveSketch->Left, AEveSketch->Top + AEveSketch->Height);
    }

    FT800_Canvas_Bitmap(0, &bmpCfg, AEveSketch->Draw_Color, AEveSketch->Opacity);
    if (*CurrentScreen->EveAnimation == (unsigned short*)AEveSketch) {
      FT800_Screen_SketchCP(sketchBmpX, sketchBmpY, bmpCfg.Size.Width, bmpCfg.Size.Height);
    }
    FT800_Screen_Bitmap(sketchBmpX, sketchBmpY);
  }
}

void DrawEveButton(TEveButton *AEveButton) {
  unsigned long drawOptions;
  
  if (AEveButton->Visible) {
    if ((VTFT_OT_EVEBUTTON == TouchS.ActObjInfo.Type) && (AEveButton == (TEveButton *)TouchS.ActObjInfo.Obj)) {
      FT800_Canvas_BrushGradient(_FT800_BRUSH_STYLE_SOLID, _FT800_BRUSH_GR_BOTTOM_TO_TOP, AEveButton->Press_Color, AEveButton->Press_ColorTo, AEveButton->Opacity);
    }
    else {
      FT800_Canvas_BrushGradient(_FT800_BRUSH_STYLE_SOLID, _FT800_BRUSH_GR_BOTTOM_TO_TOP, AEveButton->Color, AEveButton->ColorTo, AEveButton->Opacity);
    }

    if (AEveButton->FontHandle >= 16)
      FT800_Canvas_FontSystem(AEveButton->FontHandle, AEveButton->Font_Color, AEveButton->Opacity);
    else
      FT800_Canvas_Font(AEveButton->FontHandle, AEveButton->FontName, AEveButton->Source, AEveButton->Font_Color, AEveButton->Opacity);

    if (AEveButton->Tag)
      FT800_Canvas_Tag(AEveButton->Tag);

    drawOptions = 0;
    if (AEveButton->Flat)
      drawOptions |= _FT800_CP_DRAW_OPT_FLAT;
    FT800_Canvas_CPGraphics_DrawingOptions(drawOptions);

    FT800_Screen_ButtonCP(AEveButton->Left, AEveButton->Top, AEveButton->Width, AEveButton->Height, AEveButton->Caption);
  }
}

void DrawEveNumber(TEveNumber *AEveNumber) {
  unsigned long drawOptions;
  
  if (AEveNumber->Visible) {
    if (AEveNumber->FontHandle >= 16)
      FT800_Canvas_FontSystem(AEveNumber->FontHandle, AEveNumber->Font_Color, AEveNumber->Opacity);
    else
      FT800_Canvas_Font(AEveNumber->FontHandle, AEveNumber->FontName, AEveNumber->Source, AEveNumber->Font_Color, AEveNumber->Opacity);

    if (AEveNumber->Tag)
      FT800_Canvas_Tag(AEveNumber->Tag);

    drawOptions = 0;
    if (AEveNumber->TextAlign == taCenter)
      drawOptions |= _FT800_CP_DRAW_OPT_CENTER;
    else if (AEveNumber->TextAlign == taCenterX)
      drawOptions |= _FT800_CP_DRAW_OPT_CENTERX;
    else if (AEveNumber->TextAlign == taCenterY)
      drawOptions |= _FT800_CP_DRAW_OPT_CENTERY;
    else if (AEveNumber->TextAlign == taRightX)
      drawOptions |= _FT800_CP_DRAW_OPT_RIGHTX;
    if (AEveNumber->Signed)
      drawOptions |= _FT800_CP_DRAW_OPT_SIGNED;
    drawOptions |= AEveNumber->Text_Length;
    FT800_Canvas_CPGraphics_DrawingOptions(drawOptions);

    FT800_Screen_NumberCP(AEveNumber->Left, AEveNumber->Top, AEveNumber->Value);
  }
}

void DisableEveAnimation(TScreen *AScreen) {
  *AScreen->EveAnimation = 0;
}

void EnableEveAnimation(TScreen *AScreen, void * AEveAnimation) {
  *AScreen->EveAnimation = AEveAnimation;
}

void LoadCurrentScreenResToGRAM(char loadOptions) {
  char i;
  long currSource = -1;
  long tmpDynResStart;
  TEveSketch *pEveSketch;
  void *const code *ptrO;
  TFT800BmpConfig bmpCfg;
  unsigned long eveSketchRawBmpSize;

  // dynamic resources allocation
  if (loadOptions & VTFT_LOAD_RES_DYNAMIC) {

    tmpDynResStart = CurrentScreen->DynResStart;

    i  = CurrentScreen->EveSketchesCount;
    ptrO = CurrentScreen->EveSketches;
    while (i--) {
      pEveSketch = (TEveSketch *)(*ptrO);
      pEveSketch->Source = tmpDynResStart;

      GetEveSketchBmpCfg(pEveSketch, 0, 0, &bmpCfg);
      eveSketchRawBmpSize = (unsigned long)bmpCfg.Layout.LineStride * bmpCfg.Layout.Height;

      tmpDynResStart += eveSketchRawBmpSize;

      FT800_CP_BeginUpdate();
      FT800_CP_CmdMemZero(pEveSketch->Source, eveSketchRawBmpSize);
      FT800_CP_EndUpdate();

      ptrO++;
    }

  }
}

void DrawObject(TPointer aObj, char aObjType) {
  TDrawHandler drawHandler;

  drawHandler = DrawHandlerTable[aObjType];
  if (drawHandler)
    drawHandler(aObj);
}

void DrawScreenO(TScreen *aScreen, char aOptions) {
  unsigned short cOrder, saveOrder;
  signed   int   actObjOrder;
  unsigned short pwmDuty;
  // counter variables
  char cntLabel;
  char cntEveClock;
  char cntEveGauge;
  char cntEveKeys;
  char cntEveSlider;
  char cntEveSpinner;
  char cntEveSketch;
  char cntEveButton;
  char cntEveNumber;
  // pointer variables
  TLabel      *const code *pLabel;
  TEveClock   *const code *pEveClock;
  TEveGauge   *const code *pEveGauge;
  TEveKeys    *const code *pEveKeys;
  TEveSlider  *const code *pEveSlider;
  TEveSpinner *const code *pEveSpinner;
  TEveSketch  *const code *pEveSketch;
  TEveButton  *const code *pEveButton;
  TEveNumber  *const code *pEveNumber;

  // process screen switching effects
  if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_FADE) {
    FT800_PWM_Get(0, &pwmDuty);
    FT800_PWM_FadeOut(pwmDuty, 0, pwmDuty/32? pwmDuty/32 : 1, 1);
  }
  else if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_OFF) {
    FT800_PWM_Get(0, &pwmDuty);
    FT800_PWM_Duty(0);
  }

  if (CurrentScreen != aScreen) {
    // clear active object when drawing to new screen
    memset(&TouchS.ActObjInfo, 0, sizeof(TObjInfo));
  }

  CurrentScreen = aScreen;

  LoadCurrentScreenResToGRAM(aOptions);

  // init counter variables
  cntLabel      = CurrentScreen->LabelsCount;
  cntEveClock   = CurrentScreen->EveClocksCount;
  cntEveGauge   = CurrentScreen->EveGaugesCount;
  cntEveKeys    = CurrentScreen->EveKeysCount;
  cntEveSlider  = CurrentScreen->EveSlidersCount;
  cntEveSpinner = CurrentScreen->EveSpinnersCount;
  cntEveSketch  = CurrentScreen->EveSketchesCount;
  cntEveButton  = CurrentScreen->EveButtonsCount;
  cntEveNumber  = CurrentScreen->EveNumbersCount;
  // init pointer variables
  pLabel      = CurrentScreen->Labels;
  pEveClock   = CurrentScreen->EveClocks;
  pEveGauge   = CurrentScreen->EveGauges;
  pEveKeys    = CurrentScreen->EveKeys;
  pEveSlider  = CurrentScreen->EveSliders;
  pEveSpinner = CurrentScreen->EveSpinners;
  pEveSketch  = CurrentScreen->EveSketches;
  pEveButton  = CurrentScreen->EveButtons;
  pEveNumber  = CurrentScreen->EveNumbers;

  FT800_Screen_BeginUpdateCP();
  FT800_Canvas_BrushSingleColor(_FT800_BRUSH_STYLE_SOLID, CurrentScreen->Color, 255);
  FT800_Canvas_Tag(0);
  FT800_Screen_Clear(_FT800_CLEAR_ALL);
  FT800_CP_CmdStop();

  actObjOrder = -1;
  if (TouchS.ActObjInfo.Obj)
    if (TouchS.ActObjInfo.Flags & VTFT_INT_BRING_TO_FRONT)
      actObjOrder = TouchS.ActObjInfo.Order;

  cOrder = 0;
  while (cOrder < CurrentScreen->ObjectsCount) {
    saveOrder = cOrder;
    if (pLabel) {
      while ((*pLabel)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawLabel(*pLabel);
        cOrder++;
        pLabel++;
        cntLabel--;
        if (!cntLabel) {
          pLabel = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveClock) {
      while ((*pEveClock)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveClock(*pEveClock);
        cOrder++;
        pEveClock++;
        cntEveClock--;
        if (!cntEveClock) {
          pEveClock = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveGauge) {
      while ((*pEveGauge)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveGauge(*pEveGauge);
        cOrder++;
        pEveGauge++;
        cntEveGauge--;
        if (!cntEveGauge) {
          pEveGauge = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveKeys) {
      while ((*pEveKeys)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveKeys(*pEveKeys);
        cOrder++;
        pEveKeys++;
        cntEveKeys--;
        if (!cntEveKeys) {
          pEveKeys = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveSlider) {
      while ((*pEveSlider)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveSlider(*pEveSlider);
        cOrder++;
        pEveSlider++;
        cntEveSlider--;
        if (!cntEveSlider) {
          pEveSlider = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveSketch) {
      while ((*pEveSketch)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveSketch(*pEveSketch);
        cOrder++;
        pEveSketch++;
        cntEveSketch--;
        if (!cntEveSketch) {
          pEveSketch = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveButton) {
      while ((*pEveButton)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveButton(*pEveButton);
        cOrder++;
        pEveButton++;
        cntEveButton--;
        if (!cntEveButton) {
          pEveButton = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    if (pEveNumber) {
      while ((*pEveNumber)->Order == cOrder) {
        if (actObjOrder != cOrder) // draw pressed object at the end
          DrawEveNumber(*pEveNumber);
        cOrder++;
        pEveNumber++;
        cntEveNumber--;
        if (!cntEveNumber) {
          pEveNumber = 0;
          break;
        }
      }
      if (saveOrder != cOrder)
        continue;
    }

    cOrder++;
  }

  // draw pressed object now
  if (TouchS.ActObjInfo.Obj)
    DrawObject(TouchS.ActObjInfo.Obj, TouchS.ActObjInfo.Type);

  while(cntEveSpinner > 0) {
    if(DrawEveSpinner(*pEveSpinner) != 0) {
      break;
    }
    pEveSpinner++;
    cntEveSpinner--;
  }

  if(cntEveSpinner == 0) {
    FT800_Screen_EndUpdate();
    FT800_Screen_Show();
  }
  else {
    FT800_CP_EndUpdate();
    FT800_Display_WaitSwapComplete(2000);
  }

  // process screen switching effects
  if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_FADE) {
    FT800_PWM_FadeIn(0, pwmDuty, 1, 3);
  }
  else if (aOptions & VTFT_DISPLAY_EFF_LIGHTS_OFF) {
    FT800_PWM_Duty(pwmDuty);
  }

}

void DrawScreen(TScreen *aScreen) {
  if (aScreen != CurrentScreen)
    DrawScreenO(aScreen, VTFT_LOAD_RES_ALL | VTFT_DISPLAY_EFF_LIGHTS_FADE);
  else
    DrawScreenO(aScreen, VTFT_LOAD_RES_NONE);
}

char GetActiveObjectByXY(int X, int Y, TObjInfo *AObjInfo) {
  char i;
  int  hiOrder;
  TLabel      *pLabel;
  TEveClock   *pEveClock;
  TEveGauge   *pEveGauge;
  TEveKeys    *pEveKeys;
  TEveSlider  *pEveSlider;
  TEveSketch  *pEveSketch;
  TEveButton  *pEveButton;
  TEveNumber  *pEveNumber;
  void *const code *ptrO;

  // clear current object info
  memset(AObjInfo, 0, sizeof(TObjInfo));

  // Find object with highest order at specified position.
  // Objects lists are sorted by object order ascending.
  hiOrder = -1;

  // Label
  i    = CurrentScreen->LabelsCount;
  ptrO = CurrentScreen->Labels+CurrentScreen->LabelsCount-1;
  while (i--) {
    pLabel = (TLabel *)(*ptrO);
    if (pLabel->Order < hiOrder)
      break;
    if (pLabel->Active) {
      if ((pLabel->Left <= X) && (pLabel->Left+pLabel->Width-1 >= X) &&
          (pLabel->Top  <= Y) && (pLabel->Top+pLabel->Height-1 >= Y)) {
        AObjInfo->Obj   = (void *)pLabel;
        AObjInfo->Type  = VTFT_OT_LABEL;
        AObjInfo->Order = pLabel->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;

        hiOrder         = pLabel->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveClock
  i    = CurrentScreen->EveClocksCount;
  ptrO = CurrentScreen->EveClocks+CurrentScreen->EveClocksCount-1;
  while (i--) {
    pEveClock = (TEveClock *)(*ptrO);
    if (pEveClock->Order < hiOrder)
      break;
    if (pEveClock->Active) {
      // for circle objects common object width is its radius property
      if ((pEveClock->Left <= X) && (pEveClock->Left+pEveClock->Radius*2-1 >= X) &&
          (pEveClock->Top  <= Y) && (pEveClock->Top+pEveClock->Radius*2-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveClock;
        AObjInfo->Type  = VTFT_OT_EVECLOCK;
        AObjInfo->Order = pEveClock->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if (pEveClock->Press_Color != pEveClock->Color)
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

        hiOrder         = pEveClock->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveGauge
  i    = CurrentScreen->EveGaugesCount;
  ptrO = CurrentScreen->EveGauges+CurrentScreen->EveGaugesCount-1;
  while (i--) {
    pEveGauge = (TEveGauge *)(*ptrO);
    if (pEveGauge->Order < hiOrder)
      break;
    if (pEveGauge->Active) {
      // for circle objects common object width is its radius property
      if ((pEveGauge->Left <= X) && (pEveGauge->Left+pEveGauge->Radius*2-1 >= X) &&
          (pEveGauge->Top  <= Y) && (pEveGauge->Top+pEveGauge->Radius*2-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveGauge;
        AObjInfo->Type  = VTFT_OT_EVEGAUGE;
        AObjInfo->Order = pEveGauge->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if (pEveGauge->Press_Color != pEveGauge->Color)
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

        hiOrder         = pEveGauge->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveKeys
  i    = CurrentScreen->EveKeysCount;
  ptrO = CurrentScreen->EveKeys+CurrentScreen->EveKeysCount-1;
  while (i--) {
    pEveKeys = (TEveKeys *)(*ptrO);
    if (pEveKeys->Order < hiOrder)
      break;
    if (pEveKeys->Active) {
      if ((pEveKeys->Left <= X) && (pEveKeys->Left+pEveKeys->Width-1 >= X) &&
          (pEveKeys->Top  <= Y) && (pEveKeys->Top+pEveKeys->Height-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveKeys;
        AObjInfo->Type  = VTFT_OT_EVEKEYS;
        AObjInfo->Order = pEveKeys->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if ((pEveKeys->Press_Color != pEveKeys->Color) ||
            (pEveKeys->Press_ColorTo != pEveKeys->ColorTo))
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

        hiOrder         = pEveKeys->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveSlider
  i    = CurrentScreen->EveSlidersCount;
  ptrO = CurrentScreen->EveSliders+CurrentScreen->EveSlidersCount-1;
  while (i--) {
    pEveSlider = (TEveSlider *)(*ptrO);
    if (pEveSlider->Order < hiOrder)
      break;
    if (pEveSlider->Active) {
      if ((pEveSlider->Left <= X) && (pEveSlider->Left+pEveSlider->Width-1 >= X) &&
          (pEveSlider->Top  <= Y) && (pEveSlider->Top+pEveSlider->Height-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveSlider;
        AObjInfo->Type  = VTFT_OT_EVESLIDER;
        AObjInfo->Order = pEveSlider->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if (pEveSlider->Press_Color != pEveSlider->Color)
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

        hiOrder         = pEveSlider->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveSketch
  i    = CurrentScreen->EveSketchesCount;
  ptrO = CurrentScreen->EveSketches+CurrentScreen->EveSketchesCount-1;
  while (i--) {
    pEveSketch = (TEveSketch *)(*ptrO);
    if (pEveSketch->Order < hiOrder)
      break;
    if (pEveSketch->Active) {
      if ((pEveSketch->Left <= X) && (pEveSketch->Left+pEveSketch->Width-1 >= X) &&
          (pEveSketch->Top  <= Y) && (pEveSketch->Top+pEveSketch->Height-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveSketch;
        AObjInfo->Type  = VTFT_OT_EVESKETCH;
        AObjInfo->Order = pEveSketch->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;

        hiOrder         = pEveSketch->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveButton
  i    = CurrentScreen->EveButtonsCount;
  ptrO = CurrentScreen->EveButtons+CurrentScreen->EveButtonsCount-1;
  while (i--) {
    pEveButton = (TEveButton *)(*ptrO);
    if (pEveButton->Order < hiOrder)
      break;
    if (pEveButton->Active) {
      if ((pEveButton->Left <= X) && (pEveButton->Left+pEveButton->Width-1 >= X) &&
          (pEveButton->Top  <= Y) && (pEveButton->Top+pEveButton->Height-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveButton;
        AObjInfo->Type  = VTFT_OT_EVEBUTTON;
        AObjInfo->Order = pEveButton->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if ((pEveButton->Press_Color != pEveButton->Color) ||
            (pEveButton->Press_ColorTo != pEveButton->ColorTo))
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

        hiOrder         = pEveButton->Order;

        break;
      }
    }
    ptrO--;
  }

  // EveNumber
  i    = CurrentScreen->EveNumbersCount;
  ptrO = CurrentScreen->EveNumbers+CurrentScreen->EveNumbersCount-1;
  while (i--) {
    pEveNumber = (TEveNumber *)(*ptrO);
    if (pEveNumber->Order < hiOrder)
      break;
    if (pEveNumber->Active) {
      if ((pEveNumber->Left <= X) && (pEveNumber->Left+pEveNumber->Width-1 >= X) &&
          (pEveNumber->Top  <= Y) && (pEveNumber->Top+pEveNumber->Height-1 >= Y)) {
        AObjInfo->Obj   = (void *)pEveNumber;
        AObjInfo->Type  = VTFT_OT_EVENUMBER;
        AObjInfo->Order = pEveNumber->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;

        hiOrder         = pEveNumber->Order;

        break;
      }
    }
    ptrO--;
  }

  if (AObjInfo->Obj) {
    AObjInfo->HitX = X;
    AObjInfo->HitY = Y;
    return 1;
  }
  else {
    return 0;
  }
}

char GetActiveObjectByTag(char ATag, TObjInfo *AObjInfo) {
  char i;
  TLabel      *pLabel;
  TEveClock   *pEveClock;
  TEveGauge   *pEveGauge;
  TEveKeys    *pEveKeys;
  TEveSlider  *pEveSlider;
  TEveSketch  *pEveSketch;
  TEveButton  *pEveButton;
  TEveNumber  *pEveNumber;
  void *const code *ptrO;

  // clear current object info
  memset(AObjInfo, 0, sizeof(TObjInfo));

  // Find object with specified tag value.

  // Label
  i    = CurrentScreen->LabelsCount;
  ptrO = CurrentScreen->Labels+CurrentScreen->LabelsCount-1;
  while (i--) {
    pLabel = (TLabel *)(*ptrO);
    if (pLabel->Tag == ATag) {
      if (pLabel->Active) {
        AObjInfo->Obj   = (void *)pLabel;
        AObjInfo->Type  = VTFT_OT_LABEL;
        AObjInfo->Order = pLabel->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
      }
      break;
    }
    ptrO--;
  }

  // EveClock
  i    = CurrentScreen->EveClocksCount;
  ptrO = CurrentScreen->EveClocks+CurrentScreen->EveClocksCount-1;
  while (i--) {
    pEveClock = (TEveClock *)(*ptrO);
    if (pEveClock->Tag == ATag) {
      if (pEveClock->Active) {
        AObjInfo->Obj   = (void *)pEveClock;
        AObjInfo->Type  = VTFT_OT_EVECLOCK;
        AObjInfo->Order = pEveClock->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if (pEveClock->Press_Color != pEveClock->Color)
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

      }
      break;
    }
    ptrO--;
  }

  // EveGauge
  i    = CurrentScreen->EveGaugesCount;
  ptrO = CurrentScreen->EveGauges+CurrentScreen->EveGaugesCount-1;
  while (i--) {
    pEveGauge = (TEveGauge *)(*ptrO);
    if (pEveGauge->Tag == ATag) {
      if (pEveGauge->Active) {
        AObjInfo->Obj   = (void *)pEveGauge;
        AObjInfo->Type  = VTFT_OT_EVEGAUGE;
        AObjInfo->Order = pEveGauge->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if (pEveGauge->Press_Color != pEveGauge->Color)
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

      }
      break;
    }
    ptrO--;
  }

  // EveKeys
  i    = CurrentScreen->EveKeysCount;
  ptrO = CurrentScreen->EveKeys+CurrentScreen->EveKeysCount-1;
  while (i--) {
    pEveKeys = (TEveKeys *)(*ptrO);
    if (pEveKeys->Tag == ATag) {
      if (pEveKeys->Active) {
        AObjInfo->Obj   = (void *)pEveKeys;
        AObjInfo->Type  = VTFT_OT_EVEKEYS;
        AObjInfo->Order = pEveKeys->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if ((pEveKeys->Press_Color != pEveKeys->Color) ||
            (pEveKeys->Press_ColorTo != pEveKeys->ColorTo))
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

      }
      break;
    }
    ptrO--;
  }

  // EveSlider
  i    = CurrentScreen->EveSlidersCount;
  ptrO = CurrentScreen->EveSliders+CurrentScreen->EveSlidersCount-1;
  while (i--) {
    pEveSlider = (TEveSlider *)(*ptrO);
    if (pEveSlider->Tag == ATag) {
      if (pEveSlider->Active) {
        AObjInfo->Obj   = (void *)pEveSlider;
        AObjInfo->Type  = VTFT_OT_EVESLIDER;
        AObjInfo->Order = pEveSlider->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if (pEveSlider->Press_Color != pEveSlider->Color)
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

      }
      break;
    }
    ptrO--;
  }

  // EveSketch
  i    = CurrentScreen->EveSketchesCount;
  ptrO = CurrentScreen->EveSketches+CurrentScreen->EveSketchesCount-1;
  while (i--) {
    pEveSketch = (TEveSketch *)(*ptrO);
    if (pEveSketch->Tag == ATag) {
      if (pEveSketch->Active) {
        AObjInfo->Obj   = (void *)pEveSketch;
        AObjInfo->Type  = VTFT_OT_EVESKETCH;
        AObjInfo->Order = pEveSketch->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
      }
      break;
    }
    ptrO--;
  }

  // EveButton
  i    = CurrentScreen->EveButtonsCount;
  ptrO = CurrentScreen->EveButtons+CurrentScreen->EveButtonsCount-1;
  while (i--) {
    pEveButton = (TEveButton *)(*ptrO);
    if (pEveButton->Tag == ATag) {
      if (pEveButton->Active) {
        AObjInfo->Obj   = (void *)pEveButton;
        AObjInfo->Type  = VTFT_OT_EVEBUTTON;
        AObjInfo->Order = pEveButton->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
        if ((pEveButton->Press_Color != pEveButton->Color) ||
            (pEveButton->Press_ColorTo != pEveButton->ColorTo))
          AObjInfo->Flags |= VTFT_INT_REPAINT_ON_DOWN | VTFT_INT_REPAINT_ON_UP;

      }
      break;
    }
    ptrO--;
  }

  // EveNumber
  i    = CurrentScreen->EveNumbersCount;
  ptrO = CurrentScreen->EveNumbers+CurrentScreen->EveNumbersCount-1;
  while (i--) {
    pEveNumber = (TEveNumber *)(*ptrO);
    if (pEveNumber->Tag == ATag) {
      if (pEveNumber->Active) {
        AObjInfo->Obj   = (void *)pEveNumber;
        AObjInfo->Type  = VTFT_OT_EVENUMBER;
        AObjInfo->Order = pEveNumber->Order;
        AObjInfo->Flags = VTFT_INT_BRING_TO_FRONT;
      }
      break;
    }
    ptrO--;
  }

  if (AObjInfo->Obj) {
    AObjInfo->HitTag = ATag;
    return 1;
  }
  else {
    return 0;
  }
}

static void ProcessEvent(TEvent *pEvent) {
  if (pEvent) {
    if (pEvent->Sound.SndAct == VTFT_SNDACT_PLAY) 
      FT800_Sound_SetAndPlay(pEvent->Sound.Effect, pEvent->Sound.Pitch, pEvent->Sound.Volume);
    else if (pEvent->Sound.SndAct == VTFT_SNDACT_STOP) 
      FT800_Sound_Stop();
    if (pEvent->Action) 
      pEvent->Action();
  }
}

static void ProcessCEvent(TCEvent *pEventC) {
  if (pEventC) {
    if (pEventC->Sound.SndAct == VTFT_SNDACT_PLAY) 
      FT800_Sound_SetAndPlay(pEventC->Sound.Effect, pEventC->Sound.Pitch, pEventC->Sound.Volume);
    else if (pEventC->Sound.SndAct == VTFT_SNDACT_STOP) 
      FT800_Sound_Stop();
    if (pEventC->Action) 
      pEventC->Action();
  }
}

static void OnEvent(TObjInfo *AObjInfo, char AEventType){
  TEvent **ppEvent;
  TEvent  *pEvent = 0;

  switch (AObjInfo->Type) {
    // Label
    case VTFT_OT_LABEL: {
      ppEvent = &(((TLabel *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveClock
    case VTFT_OT_EVECLOCK: {
      ppEvent = &(((TEveClock *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveGauge
    case VTFT_OT_EVEGAUGE: {
      ppEvent = &(((TEveGauge *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveKeys
    case VTFT_OT_EVEKEYS: {
      ppEvent = &(((TEveKeys *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveSlider
    case VTFT_OT_EVESLIDER: {
      ppEvent = &(((TEveSlider *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveSketch
    case VTFT_OT_EVESKETCH: {
      ppEvent = &(((TEveSketch *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveButton
    case VTFT_OT_EVEBUTTON: {
      ppEvent = &(((TEveButton *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
    // EveNumber
    case VTFT_OT_EVENUMBER: {
      ppEvent = &(((TEveNumber *)AObjInfo->Obj)->OnUp);
      pEvent  = ppEvent[AEventType];
      break;
    }
  } // end switch

  if (pEvent) {
    ProcessEvent(pEvent);
  }
}

static void Process_TP_Press() {
  // Screen Event
  if (CurrentScreen->Active)
    if ((CurrentScreen->SniffObjectEvents) || (!TouchS.ActObjInfo.Obj))
      ProcessEvent(CurrentScreen->OnPress);

  // Object Event
  if (!TouchS.ActObjInfo.Obj)
    return;

  OnEvent(&TouchS.ActObjInfo, VTFT_EVT_PRESS);
}

static void Process_TP_Up() {
  char     isClick;
  TObjInfo actObj;

  // Screen Event
  if (CurrentScreen->Active)
    if ((CurrentScreen->SniffObjectEvents) || (!TouchS.ActObjInfo.Obj))
      ProcessEvent(CurrentScreen->OnUp);

  actObj = TouchS.ActObjInfo;
  // Cler active object info
  memset(&TouchS.ActObjInfo, 0, sizeof(TObjInfo));

  // Object Event
  if (!actObj.Obj)
    return;

  isClick = IsInsideObject(&actObj, TouchS.X, TouchS.Y);

  if (actObj.Flags & VTFT_INT_REPAINT_ON_UP)
    DrawScreen(CurrentScreen);

  OnEvent(&actObj, VTFT_EVT_UP);
  if (isClick)
    OnEvent(&actObj, VTFT_EVT_CLICK);
}

static void Process_TP_Down() {
  // Search for active object
  if (TouchS.Tag) {        // objects must not have zero for tag value
    if (TouchS.Tag != 255) // can not search objects by default tag value
      GetActiveObjectByTag(TouchS.Tag, &TouchS.ActObjInfo);
    if (!TouchS.ActObjInfo.Obj) // object not found by tag, search by coordinates
      GetActiveObjectByXY(TouchS.X, TouchS.Y, &TouchS.ActObjInfo);
  }

  // Screen Event
  if (CurrentScreen->Active)
    if ((CurrentScreen->SniffObjectEvents) || (!TouchS.ActObjInfo.Obj))
      ProcessEvent(CurrentScreen->OnDown);

  // Object Event
  if (!TouchS.ActObjInfo.Obj)
    return;

  if (TouchS.ActObjInfo.Flags & VTFT_INT_REPAINT_ON_DOWN)
    DrawScreen(CurrentScreen);

  OnEvent(&TouchS.ActObjInfo, VTFT_EVT_DOWN);
}

static void Process_TP_TagChange() {
  // Screen Event
  if (CurrentScreen->Active)
    ProcessEvent(CurrentScreen->OnTagChange);
}

void ProcessVTFTStack() {
  char         Tag, oldTag;
  unsigned int X, Y;

  oldTag = TouchS.Tag;

  if (FT800_Touch_GetTagXY(&X, &Y) == 1) {
    FT800_Touch_GetTag(&Tag);

    TouchS.Tag = Tag;
    TouchS.X = X;
    TouchS.Y = Y;

    if (!TouchS.Pressed) {
      TouchS.Pressed = 1;
      Process_TP_Down();
    }

    Process_TP_Press();
  }
  else if (TouchS.Pressed) {
    Process_TP_Up();

    TouchS.Tag = 0;
    TouchS.X   = X;
    TouchS.Y   = Y;

    TouchS.Pressed = 0;
  }

  if (oldTag != TouchS.Tag)
    Process_TP_TagChange();
}

static void InitObjects() {
  // Screen1: Init block start
  Screen1.Color             = 0x74EE;
  Screen1.Width             = 480;
  Screen1.Height            = 272;
  Screen1.ObjectsCount      = 12;
  Screen1.LabelsCount       = 4;
  Screen1.Labels            = Screen1_Labels;
  Screen1.EveClocksCount    = 1;
  Screen1.EveClocks         = Screen1_EveClocks;
  Screen1.EveGaugesCount    = 1;
  Screen1.EveGauges         = Screen1_EveGauges;
  Screen1.EveKeysCount      = 0;
  Screen1.EveKeys           = 0;
  Screen1.EveSlidersCount   = 0;
  Screen1.EveSliders        = 0;
  Screen1.EveSpinnersCount  = 1;
  Screen1.EveSpinners       = Screen1_EveSpinners;
  Screen1.EveSketchesCount  = 0;
  Screen1.EveSketches       = 0;
  Screen1.EveButtonsCount   = 1;
  Screen1.EveButtons        = Screen1_EveButtons;
  Screen1.EveNumbersCount   = 4;
  Screen1.EveNumbers        = Screen1_EveNumbers;
  Screen1.DynResStart       = 0;
  Screen1.Active            = 1;
  Screen1.EveAnimation      = &ScreensEveAnimationTable[0];
  Screen1.SniffObjectEvents = 0;
  Screen1.OnUp              = 0;
  Screen1.OnDown            = 0;
  Screen1.OnTagChange       = 0;
  Screen1.OnPress           = 0;

  // Screen2: Init block start
  Screen2.Color             = 0x9659;
  Screen2.Width             = 480;
  Screen2.Height            = 272;
  Screen2.ObjectsCount      = 15;
  Screen2.LabelsCount       = 1;
  Screen2.Labels            = Screen2_Labels;
  Screen2.EveClocksCount    = 0;
  Screen2.EveClocks         = 0;
  Screen2.EveGaugesCount    = 0;
  Screen2.EveGauges         = 0;
  Screen2.EveKeysCount      = 1;
  Screen2.EveKeys           = Screen2_EveKeys;
  Screen2.EveSlidersCount   = 0;
  Screen2.EveSliders        = 0;
  Screen2.EveSpinnersCount  = 0;
  Screen2.EveSpinners       = 0;
  Screen2.EveSketchesCount  = 0;
  Screen2.EveSketches       = 0;
  Screen2.EveButtonsCount   = 8;
  Screen2.EveButtons        = Screen2_EveButtons;
  Screen2.EveNumbersCount   = 5;
  Screen2.EveNumbers        = Screen2_EveNumbers;
  Screen2.DynResStart       = 0;
  Screen2.Active            = 1;
  Screen2.EveAnimation      = &ScreensEveAnimationTable[1];
  Screen2.SniffObjectEvents = 0;
  Screen2.OnUp              = 0;
  Screen2.OnDown            = 0;
  Screen2.OnTagChange       = 0;
  Screen2.OnPress           = 0;

  // Screen3: Init block start
  Screen3.Color             = 0xD01A;
  Screen3.Width             = 480;
  Screen3.Height            = 272;
  Screen3.ObjectsCount      = 6;
  Screen3.LabelsCount       = 0;
  Screen3.Labels            = 0;
  Screen3.EveClocksCount    = 0;
  Screen3.EveClocks         = 0;
  Screen3.EveGaugesCount    = 0;
  Screen3.EveGauges         = 0;
  Screen3.EveKeysCount      = 0;
  Screen3.EveKeys           = 0;
  Screen3.EveSlidersCount   = 3;
  Screen3.EveSliders        = Screen3_EveSliders;
  Screen3.EveSpinnersCount  = 0;
  Screen3.EveSpinners       = 0;
  Screen3.EveSketchesCount  = 0;
  Screen3.EveSketches       = 0;
  Screen3.EveButtonsCount   = 2;
  Screen3.EveButtons        = Screen3_EveButtons;
  Screen3.EveNumbersCount   = 1;
  Screen3.EveNumbers        = Screen3_EveNumbers;
  Screen3.DynResStart       = 0;
  Screen3.Active            = 1;
  Screen3.EveAnimation      = &ScreensEveAnimationTable[2];
  Screen3.SniffObjectEvents = 0;
  Screen3.OnUp              = 0;
  Screen3.OnDown            = 0;
  Screen3.OnTagChange       = 0;
  Screen3.OnPress           = 0;

  // Screen4: Init block start
  Screen4.Color             = 0x4410;
  Screen4.Width             = 480;
  Screen4.Height            = 272;
  Screen4.ObjectsCount      = 4;
  Screen4.LabelsCount       = 0;
  Screen4.Labels            = 0;
  Screen4.EveClocksCount    = 0;
  Screen4.EveClocks         = 0;
  Screen4.EveGaugesCount    = 0;
  Screen4.EveGauges         = 0;
  Screen4.EveKeysCount      = 0;
  Screen4.EveKeys           = 0;
  Screen4.EveSlidersCount   = 0;
  Screen4.EveSliders        = 0;
  Screen4.EveSpinnersCount  = 0;
  Screen4.EveSpinners       = 0;
  Screen4.EveSketchesCount  = 1;
  Screen4.EveSketches       = Screen4_EveSketches;
  Screen4.EveButtonsCount   = 3;
  Screen4.EveButtons        = Screen4_EveButtons;
  Screen4.EveNumbersCount   = 0;
  Screen4.EveNumbers        = 0;
  Screen4.DynResStart       = 0;
  Screen4.Active            = 1;
  Screen4.EveAnimation      = &ScreensEveAnimationTable[3];
  Screen4.SniffObjectEvents = 0;
  Screen4.OnUp              = 0;
  Screen4.OnDown            = 0;
  Screen4.OnTagChange       = 0;
  Screen4.OnPress           = 0;

  EveClock1.OwnerScreen   = &Screen1;
  EveClock1.Order         = 0;
  EveClock1.Visible       = 1;
  EveClock1.Opacity       = 255;
  EveClock1.Tag           = 255;
  EveClock1.Left          = 40;
  EveClock1.Top           = 30;
  EveClock1.Radius        = 77;
  EveClock1.Pen_Width     = 1;
  EveClock1.Pen_Color     = 0x0000;
  EveClock1.Color         = 0xFFE0;
  EveClock1.Press_Color   = 0x07E0;
  EveClock1.Hour          = 1;
  EveClock1.Min           = 15;
  EveClock1.Sec           = 30;
  EveClock1.Flat          = 0;
  EveClock1.NoBackground  = 0;
  EveClock1.HandsVisible  = 1;
  EveClock1.SecsVisible   = 1;
  EveClock1.TicksVisible  = 1;
  EveClock1.Active        = 1;
  EveClock1.OnUp          = 0;
  EveClock1.OnDown        = 0;
  EveClock1.OnClick       = 0;
  EveClock1.OnPress       = &EveClock1_OnPress;

  EveClock1_OnPress.Action       = page_2;
  EveClock1_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveClock1_OnPress.Sound.Effect = _FT800_SOUND_XYLOPHONE;
  EveClock1_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveClock1_OnPress.Sound.Volume = 255;

  EveButton1.OwnerScreen   = &Screen1;
  EveButton1.Order         = 1;
  EveButton1.Visible       = 1;
  EveButton1.Opacity       = 255;
  EveButton1.Tag           = 255;
  EveButton1.Left          = 398;
  EveButton1.Top           = 229;
  EveButton1.Width         = 80;
  EveButton1.Height        = 40;
  EveButton1.Color         = 0xFFE0;
  EveButton1.Press_Color   = 0x7E3F;
  EveButton1.ColorTo       = 0xF800;
  EveButton1.Press_ColorTo = 0x03DA;
  EveButton1.Caption       = EveButton1_Caption;
  EveButton1.FontName      = 29;
  EveButton1.Font_Color    = 0x0000;
  EveButton1.FontHandle    = 29;
  EveButton1.Source        = -1UL;
  EveButton1.Flat          = 0;
  EveButton1.Active        = 1;
  EveButton1.OnUp          = 0;
  EveButton1.OnDown        = &EveButton1_OnDown;
  EveButton1.OnClick       = 0;
  EveButton1.OnPress       = &EveButton1_OnPress;

  EveButton1_OnDown.Action       = (void *)0;
  EveButton1_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton1_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton1_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton1_OnDown.Sound.Volume = 255;

  EveButton1_OnPress.Action       = page_2;
  EveButton1_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton1_OnPress.Sound.Effect = _FT800_SOUND_HARP;
  EveButton1_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton1_OnPress.Sound.Volume = 255;

  EveNumber2.OwnerScreen = &Screen1;
  EveNumber2.Order       = 2;
  EveNumber2.Visible     = 1;
  EveNumber2.Opacity     = 255;
  EveNumber2.Tag         = 255;
  EveNumber2.Left        = 36;
  EveNumber2.Top         = 223;
  EveNumber2.Width       = 35;
  EveNumber2.Height      = 40;
  EveNumber2.Text_Length = 2;
  EveNumber2.TextAlign   = taNone;
  EveNumber2.FontName    = 30;
  EveNumber2.Font_Color  = 0xFFE0;
  EveNumber2.FontHandle  = 30;
  EveNumber2.Source      = -1UL;
  EveNumber2.Value       = 27;
  EveNumber2.Signed      = 0;
  EveNumber2.Active      = 1;
  EveNumber2.OnUp        = 0;
  EveNumber2.OnDown      = 0;
  EveNumber2.OnClick     = 0;
  EveNumber2.OnPress     = 0;

  EveNumber3.OwnerScreen = &Screen1;
  EveNumber3.Order       = 3;
  EveNumber3.Visible     = 1;
  EveNumber3.Opacity     = 255;
  EveNumber3.Tag         = 255;
  EveNumber3.Left        = 81;
  EveNumber3.Top         = 223;
  EveNumber3.Width       = 35;
  EveNumber3.Height      = 40;
  EveNumber3.Text_Length = 2;
  EveNumber3.TextAlign   = taNone;
  EveNumber3.FontName    = 30;
  EveNumber3.Font_Color  = 0xFFE0;
  EveNumber3.FontHandle  = 30;
  EveNumber3.Source      = -1UL;
  EveNumber3.Value       = 1;
  EveNumber3.Signed      = 0;
  EveNumber3.Active      = 1;
  EveNumber3.OnUp        = 0;
  EveNumber3.OnDown      = 0;
  EveNumber3.OnClick     = 0;
  EveNumber3.OnPress     = 0;

  EveNumber4.OwnerScreen = &Screen1;
  EveNumber4.Order       = 4;
  EveNumber4.Visible     = 1;
  EveNumber4.Opacity     = 255;
  EveNumber4.Tag         = 255;
  EveNumber4.Left        = 126;
  EveNumber4.Top         = 223;
  EveNumber4.Width       = 70;
  EveNumber4.Height      = 40;
  EveNumber4.Text_Length = 4;
  EveNumber4.TextAlign   = taNone;
  EveNumber4.FontName    = 30;
  EveNumber4.Font_Color  = 0xFFE0;
  EveNumber4.FontHandle  = 30;
  EveNumber4.Source      = -1UL;
  EveNumber4.Value       = 2016;
  EveNumber4.Signed      = 0;
  EveNumber4.Active      = 1;
  EveNumber4.OnUp        = 0;
  EveNumber4.OnDown      = 0;
  EveNumber4.OnClick     = 0;
  EveNumber4.OnPress     = 0;

  EveGauge1.OwnerScreen   = &Screen1;
  EveGauge1.Order         = 5;
  EveGauge1.Visible       = 1;
  EveGauge1.Opacity       = 255;
  EveGauge1.Tag           = 255;
  EveGauge1.Left          = 235;
  EveGauge1.Top           = 30;
  EveGauge1.Radius        = 77;
  EveGauge1.Pen_Width     = 1;
  EveGauge1.Pen_Color     = 0x0000;
  EveGauge1.Color         = 0xFFE0;
  EveGauge1.Press_Color   = 0xF800;
  EveGauge1.Major         = 10;
  EveGauge1.Minor         = 5;
  EveGauge1.Value         = 0;
  EveGauge1.Range         = 100;
  EveGauge1.Flat          = 0;
  EveGauge1.NoBackground  = 0;
  EveGauge1.NoPointer     = 0;
  EveGauge1.TicksVisible  = 1;
  EveGauge1.Active        = 1;
  EveGauge1.OnUp          = &EveGauge1_OnUp;
  EveGauge1.OnDown        = &EveGauge1_OnDown;
  EveGauge1.OnClick       = 0;
  EveGauge1.OnPress       = 0;

  EveGauge1_OnUp.Action       = (void *)0;
  EveGauge1_OnUp.Sound.SndAct = VTFT_SNDACT_STOP;
  EveGauge1_OnUp.Sound.Effect = _FT800_SOUND_XYLOPHONE;
  EveGauge1_OnUp.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveGauge1_OnUp.Sound.Volume = 255;

  EveGauge1_OnDown.Action       = (void *)0;
  EveGauge1_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveGauge1_OnDown.Sound.Effect = _FT800_SOUND_CAROUSEL;
  EveGauge1_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveGauge1_OnDown.Sound.Volume = 255;

  Label2.OwnerScreen = &Screen1;
  Label2.Order       = 6;
  Label2.Visible     = 1;
  Label2.Opacity     = 255;
  Label2.Tag         = 255;
  Label2.Left        = 79;
  Label2.Top         = 190;
  Label2.Width       = 74;
  Label2.Height      = 30;
  Label2.Caption     = Label2_Caption;
  Label2.FontName    = 29;
  Label2.Font_Color  = 0xFFFF;
  Label2.FontHandle  = 29;
  Label2.Source      = -1UL;
  Label2.Active      = 1;
  Label2.OnUp        = 0;
  Label2.OnDown      = 0;
  Label2.OnClick     = 0;
  Label2.OnPress     = 0;

  Label3.OwnerScreen = &Screen1;
  Label3.Order       = 7;
  Label3.Visible     = 1;
  Label3.Opacity     = 255;
  Label3.Tag         = 255;
  Label3.Left        = 234;
  Label3.Top         = 190;
  Label3.Width       = 164;
  Label3.Height      = 30;
  Label3.Caption     = Label3_Caption;
  Label3.FontName    = 29;
  Label3.Font_Color  = 0xFFFF;
  Label3.FontHandle  = 29;
  Label3.Source      = -1UL;
  Label3.Active      = 1;
  Label3.OnUp        = 0;
  Label3.OnDown      = 0;
  Label3.OnClick     = 0;
  Label3.OnPress     = 0;

  EveNumber10.OwnerScreen = &Screen1;
  EveNumber10.Order       = 8;
  EveNumber10.Visible     = 1;
  EveNumber10.Opacity     = 255;
  EveNumber10.Tag         = 255;
  EveNumber10.Left        = 292;
  EveNumber10.Top         = 150;
  EveNumber10.Width       = 27;
  EveNumber10.Height      = 30;
  EveNumber10.Text_Length = 2;
  EveNumber10.TextAlign   = taNone;
  EveNumber10.FontName    = 29;
  EveNumber10.Font_Color  = 0x0000;
  EveNumber10.FontHandle  = 29;
  EveNumber10.Source      = -1UL;
  EveNumber10.Value       = 5;
  EveNumber10.Signed      = 0;
  EveNumber10.Active      = 1;
  EveNumber10.OnUp        = 0;
  EveNumber10.OnDown      = 0;
  EveNumber10.OnClick     = 0;
  EveNumber10.OnPress     = 0;

  Label4.OwnerScreen = &Screen1;
  Label4.Order       = 9;
  Label4.Visible     = 1;
  Label4.Opacity     = 255;
  Label4.Tag         = 255;
  Label4.Left        = 321;
  Label4.Top         = 150;
  Label4.Width       = 15;
  Label4.Height      = 30;
  Label4.Caption     = Label4_Caption;
  Label4.FontName    = 29;
  Label4.Font_Color  = 0x0000;
  Label4.FontHandle  = 29;
  Label4.Source      = -1UL;
  Label4.Active      = 1;
  Label4.OnUp        = 0;
  Label4.OnDown      = 0;
  Label4.OnClick     = 0;
  Label4.OnPress     = 0;

  Label5.OwnerScreen = &Screen1;
  Label5.Order       = 10;
  Label5.Visible     = 1;
  Label5.Opacity     = 255;
  Label5.Tag         = 255;
  Label5.Left        = 279;
  Label5.Top         = 150;
  Label5.Width       = 11;
  Label5.Height      = 30;
  Label5.Caption     = Label5_Caption;
  Label5.FontName    = 29;
  Label5.Font_Color  = 0x0000;
  Label5.FontHandle  = 29;
  Label5.Source      = -1UL;
  Label5.Active      = 1;
  Label5.OnUp        = 0;
  Label5.OnDown      = 0;
  Label5.OnClick     = 0;
  Label5.OnPress     = 0;

  EveSpinner1.OwnerScreen   = &Screen1;
  EveSpinner1.Tag           = 255;
  EveSpinner1.Left          = 437;
  EveSpinner1.Top           = 104;
  EveSpinner1.Color         = 0xFFE0;
  EveSpinner1.Style         = 0;
  EveSpinner1.Scale         = 0;

  Label1.OwnerScreen = &Screen2;
  Label1.Order       = 0;
  Label1.Visible     = 1;
  Label1.Opacity     = 255;
  Label1.Tag         = 255;
  Label1.Left        = 100;
  Label1.Top         = 6;
  Label1.Width       = 266;
  Label1.Height      = 53;
  Label1.Caption     = Label1_Caption;
  Label1.FontName    = 31;
  Label1.Font_Color  = 0xFFE0;
  Label1.FontHandle  = 31;
  Label1.Source      = -1UL;
  Label1.Active      = 1;
  Label1.OnUp        = 0;
  Label1.OnDown      = 0;
  Label1.OnClick     = 0;
  Label1.OnPress     = 0;

  EveButton4.OwnerScreen   = &Screen2;
  EveButton4.Order         = 1;
  EveButton4.Visible       = 1;
  EveButton4.Opacity       = 255;
  EveButton4.Tag           = 255;
  EveButton4.Left          = 20;
  EveButton4.Top           = 69;
  EveButton4.Width         = 81;
  EveButton4.Height        = 40;
  EveButton4.Color         = 0x03DA;
  EveButton4.Press_Color   = 0x7E3F;
  EveButton4.ColorTo       = 0x7E3F;
  EveButton4.Press_ColorTo = 0x03DA;
  EveButton4.Caption       = EveButton4_Caption;
  EveButton4.FontName      = 28;
  EveButton4.Font_Color    = 0x0000;
  EveButton4.FontHandle    = 28;
  EveButton4.Source        = -1UL;
  EveButton4.Flat          = 0;
  EveButton4.Active        = 1;
  EveButton4.OnUp          = 0;
  EveButton4.OnDown        = &EveButton4_OnDown;
  EveButton4.OnClick       = 0;
  EveButton4.OnPress       = &EveButton4_OnPress;

  EveButton4_OnDown.Action       = (void *)0;
  EveButton4_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton4_OnDown.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton4_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton4_OnDown.Sound.Volume = 255;

  EveButton4_OnPress.Action       = minute;
  EveButton4_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton4_OnPress.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton4_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton4_OnPress.Sound.Volume = 255;

  EveButton5.OwnerScreen   = &Screen2;
  EveButton5.Order         = 2;
  EveButton5.Visible       = 1;
  EveButton5.Opacity       = 255;
  EveButton5.Tag           = 255;
  EveButton5.Left          = 110;
  EveButton5.Top           = 70;
  EveButton5.Width         = 80;
  EveButton5.Height        = 40;
  EveButton5.Color         = 0x03DA;
  EveButton5.Press_Color   = 0x7E3F;
  EveButton5.ColorTo       = 0x7E3F;
  EveButton5.Press_ColorTo = 0x03DA;
  EveButton5.Caption       = EveButton5_Caption;
  EveButton5.FontName      = 28;
  EveButton5.Font_Color    = 0x0000;
  EveButton5.FontHandle    = 28;
  EveButton5.Source        = -1UL;
  EveButton5.Flat          = 0;
  EveButton5.Active        = 1;
  EveButton5.OnUp          = 0;
  EveButton5.OnDown        = &EveButton5_OnDown;
  EveButton5.OnClick       = 0;
  EveButton5.OnPress       = &EveButton5_OnPress;

  EveButton5_OnDown.Action       = (void *)0;
  EveButton5_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton5_OnDown.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton5_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton5_OnDown.Sound.Volume = 255;

  EveButton5_OnPress.Action       = Hour;
  EveButton5_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton5_OnPress.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton5_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton5_OnPress.Sound.Volume = 255;

  EveButton6.OwnerScreen   = &Screen2;
  EveButton6.Order         = 3;
  EveButton6.Visible       = 1;
  EveButton6.Opacity       = 255;
  EveButton6.Tag           = 255;
  EveButton6.Left          = 380;
  EveButton6.Top           = 70;
  EveButton6.Width         = 80;
  EveButton6.Height        = 40;
  EveButton6.Color         = 0x03DA;
  EveButton6.Press_Color   = 0x7E3F;
  EveButton6.ColorTo       = 0x7E3F;
  EveButton6.Press_ColorTo = 0x03DA;
  EveButton6.Caption       = EveButton6_Caption;
  EveButton6.FontName      = 28;
  EveButton6.Font_Color    = 0x0000;
  EveButton6.FontHandle    = 28;
  EveButton6.Source        = -1UL;
  EveButton6.Flat          = 0;
  EveButton6.Active        = 1;
  EveButton6.OnUp          = 0;
  EveButton6.OnDown        = &EveButton6_OnDown;
  EveButton6.OnClick       = 0;
  EveButton6.OnPress       = &EveButton6_OnPress;

  EveButton6_OnDown.Action       = (void *)0;
  EveButton6_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton6_OnDown.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton6_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton6_OnDown.Sound.Volume = 255;

  EveButton6_OnPress.Action       = year;
  EveButton6_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton6_OnPress.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton6_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton6_OnPress.Sound.Volume = 255;

  EveButton7.OwnerScreen   = &Screen2;
  EveButton7.Order         = 4;
  EveButton7.Visible       = 1;
  EveButton7.Opacity       = 255;
  EveButton7.Tag           = 255;
  EveButton7.Left          = 290;
  EveButton7.Top           = 70;
  EveButton7.Width         = 80;
  EveButton7.Height        = 40;
  EveButton7.Color         = 0x03DA;
  EveButton7.Press_Color   = 0x7E3F;
  EveButton7.ColorTo       = 0x7E3F;
  EveButton7.Press_ColorTo = 0x03DA;
  EveButton7.Caption       = EveButton7_Caption;
  EveButton7.FontName      = 28;
  EveButton7.Font_Color    = 0x0000;
  EveButton7.FontHandle    = 28;
  EveButton7.Source        = -1UL;
  EveButton7.Flat          = 0;
  EveButton7.Active        = 1;
  EveButton7.OnUp          = 0;
  EveButton7.OnDown        = &EveButton7_OnDown;
  EveButton7.OnClick       = 0;
  EveButton7.OnPress       = &EveButton7_OnPress;

  EveButton7_OnDown.Action       = (void *)0;
  EveButton7_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton7_OnDown.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton7_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton7_OnDown.Sound.Volume = 255;

  EveButton7_OnPress.Action       = Mount;
  EveButton7_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton7_OnPress.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton7_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton7_OnPress.Sound.Volume = 255;

  EveButton8.OwnerScreen   = &Screen2;
  EveButton8.Order         = 5;
  EveButton8.Visible       = 1;
  EveButton8.Opacity       = 255;
  EveButton8.Tag           = 255;
  EveButton8.Left          = 200;
  EveButton8.Top           = 70;
  EveButton8.Width         = 80;
  EveButton8.Height        = 40;
  EveButton8.Color         = 0x03DA;
  EveButton8.Press_Color   = 0x7E3F;
  EveButton8.ColorTo       = 0x7E3F;
  EveButton8.Press_ColorTo = 0x03DA;
  EveButton8.Caption       = EveButton8_Caption;
  EveButton8.FontName      = 28;
  EveButton8.Font_Color    = 0x0000;
  EveButton8.FontHandle    = 28;
  EveButton8.Source        = -1UL;
  EveButton8.Flat          = 0;
  EveButton8.Active        = 1;
  EveButton8.OnUp          = 0;
  EveButton8.OnDown        = &EveButton8_OnDown;
  EveButton8.OnClick       = 0;
  EveButton8.OnPress       = &EveButton8_OnPress;

  EveButton8_OnDown.Action       = (void *)0;
  EveButton8_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton8_OnDown.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton8_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton8_OnDown.Sound.Volume = 255;

  EveButton8_OnPress.Action       = Day;
  EveButton8_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton8_OnPress.Sound.Effect = _FT800_SOUND_SHORT_PIPS_1;
  EveButton8_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton8_OnPress.Sound.Volume = 255;

  EveKeys1.OwnerScreen   = &Screen2;
  EveKeys1.Order         = 6;
  EveKeys1.Visible       = 1;
  EveKeys1.Opacity       = 255;
  EveKeys1.Tag           = 255;
  EveKeys1.Left          = 5;
  EveKeys1.Top           = 149;
  EveKeys1.Width         = 470;
  EveKeys1.Height        = 60;
  EveKeys1.Color         = 0x03DA;
  EveKeys1.Press_Color   = 0x7E3F;
  EveKeys1.ColorTo       = 0x7E3F;
  EveKeys1.Press_ColorTo = 0x03DA;
  EveKeys1.Caption       = EveKeys1_Caption;
  EveKeys1.FontName      = 28;
  EveKeys1.Font_Color    = 0x0000;
  EveKeys1.FontHandle    = 28;
  EveKeys1.Source        = -1UL;
  EveKeys1.Flat          = 0;
  EveKeys1.AutoSize      = 0;
  EveKeys1.Active        = 1;
  EveKeys1.OnUp          = 0;
  EveKeys1.OnDown        = &EveKeys1_OnDown;
  EveKeys1.OnClick       = 0;
  EveKeys1.OnPress       = &EveKeys1_OnPress;

  EveKeys1_OnDown.Action       = (void *)0;
  EveKeys1_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveKeys1_OnDown.Sound.Effect = _FT800_SOUND_CLICK;
  EveKeys1_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveKeys1_OnDown.Sound.Volume = 255;

  EveKeys1_OnPress.Action       = keypad;
  EveKeys1_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveKeys1_OnPress.Sound.Effect = _FT800_SOUND_XYLOPHONE;
  EveKeys1_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveKeys1_OnPress.Sound.Volume = 255;

  EveNumber5.OwnerScreen = &Screen2;
  EveNumber5.Order       = 7;
  EveNumber5.Visible     = 1;
  EveNumber5.Opacity     = 255;
  EveNumber5.Tag         = 255;
  EveNumber5.Left        = 40;
  EveNumber5.Top         = 110;
  EveNumber5.Width       = 35;
  EveNumber5.Height      = 40;
  EveNumber5.Text_Length = 2;
  EveNumber5.TextAlign   = taNone;
  EveNumber5.FontName    = 30;
  EveNumber5.Font_Color  = 0x0000;
  EveNumber5.FontHandle  = 30;
  EveNumber5.Source      = -1UL;
  EveNumber5.Value       = 0;
  EveNumber5.Signed      = 0;
  EveNumber5.Active      = 1;
  EveNumber5.OnUp        = 0;
  EveNumber5.OnDown      = 0;
  EveNumber5.OnClick     = 0;
  EveNumber5.OnPress     = 0;

  EveNumber6.OwnerScreen = &Screen2;
  EveNumber6.Order       = 8;
  EveNumber6.Visible     = 1;
  EveNumber6.Opacity     = 255;
  EveNumber6.Tag         = 255;
  EveNumber6.Left        = 130;
  EveNumber6.Top         = 110;
  EveNumber6.Width       = 35;
  EveNumber6.Height      = 40;
  EveNumber6.Text_Length = 2;
  EveNumber6.TextAlign   = taNone;
  EveNumber6.FontName    = 30;
  EveNumber6.Font_Color  = 0x0000;
  EveNumber6.FontHandle  = 30;
  EveNumber6.Source      = -1UL;
  EveNumber6.Value       = 0;
  EveNumber6.Signed      = 0;
  EveNumber6.Active      = 1;
  EveNumber6.OnUp        = 0;
  EveNumber6.OnDown      = 0;
  EveNumber6.OnClick     = 0;
  EveNumber6.OnPress     = 0;

  EveNumber7.OwnerScreen = &Screen2;
  EveNumber7.Order       = 9;
  EveNumber7.Visible     = 1;
  EveNumber7.Opacity     = 255;
  EveNumber7.Tag         = 255;
  EveNumber7.Left        = 220;
  EveNumber7.Top         = 110;
  EveNumber7.Width       = 35;
  EveNumber7.Height      = 40;
  EveNumber7.Text_Length = 2;
  EveNumber7.TextAlign   = taNone;
  EveNumber7.FontName    = 30;
  EveNumber7.Font_Color  = 0x0000;
  EveNumber7.FontHandle  = 30;
  EveNumber7.Source      = -1UL;
  EveNumber7.Value       = 0;
  EveNumber7.Signed      = 0;
  EveNumber7.Active      = 1;
  EveNumber7.OnUp        = 0;
  EveNumber7.OnDown      = 0;
  EveNumber7.OnClick     = 0;
  EveNumber7.OnPress     = 0;

  EveNumber8.OwnerScreen = &Screen2;
  EveNumber8.Order       = 10;
  EveNumber8.Visible     = 1;
  EveNumber8.Opacity     = 255;
  EveNumber8.Tag         = 255;
  EveNumber8.Left        = 310;
  EveNumber8.Top         = 110;
  EveNumber8.Width       = 35;
  EveNumber8.Height      = 40;
  EveNumber8.Text_Length = 2;
  EveNumber8.TextAlign   = taNone;
  EveNumber8.FontName    = 30;
  EveNumber8.Font_Color  = 0x0000;
  EveNumber8.FontHandle  = 30;
  EveNumber8.Source      = -1UL;
  EveNumber8.Value       = 0;
  EveNumber8.Signed      = 0;
  EveNumber8.Active      = 1;
  EveNumber8.OnUp        = 0;
  EveNumber8.OnDown      = 0;
  EveNumber8.OnClick     = 0;
  EveNumber8.OnPress     = 0;

  EveNumber9.OwnerScreen = &Screen2;
  EveNumber9.Order       = 11;
  EveNumber9.Visible     = 1;
  EveNumber9.Opacity     = 255;
  EveNumber9.Tag         = 255;
  EveNumber9.Left        = 400;
  EveNumber9.Top         = 110;
  EveNumber9.Width       = 35;
  EveNumber9.Height      = 40;
  EveNumber9.Text_Length = 2;
  EveNumber9.TextAlign   = taNone;
  EveNumber9.FontName    = 30;
  EveNumber9.Font_Color  = 0x0000;
  EveNumber9.FontHandle  = 30;
  EveNumber9.Source      = -1UL;
  EveNumber9.Value       = 0;
  EveNumber9.Signed      = 0;
  EveNumber9.Active      = 1;
  EveNumber9.OnUp        = 0;
  EveNumber9.OnDown      = 0;
  EveNumber9.OnClick     = 0;
  EveNumber9.OnPress     = 0;

  EveButton11.OwnerScreen   = &Screen2;
  EveButton11.Order         = 12;
  EveButton11.Visible       = 1;
  EveButton11.Opacity       = 255;
  EveButton11.Tag           = 255;
  EveButton11.Left          = 198;
  EveButton11.Top           = 228;
  EveButton11.Width         = 80;
  EveButton11.Height        = 40;
  EveButton11.Color         = 0x03DA;
  EveButton11.Press_Color   = 0x7E3F;
  EveButton11.ColorTo       = 0x7E3F;
  EveButton11.Press_ColorTo = 0x03DA;
  EveButton11.Caption       = EveButton11_Caption;
  EveButton11.FontName      = 28;
  EveButton11.Font_Color    = 0x0000;
  EveButton11.FontHandle    = 28;
  EveButton11.Source        = -1UL;
  EveButton11.Flat          = 0;
  EveButton11.Active        = 1;
  EveButton11.OnUp          = 0;
  EveButton11.OnDown        = &EveButton11_OnDown;
  EveButton11.OnClick       = 0;
  EveButton11.OnPress       = &EveButton11_OnPress;

  EveButton11_OnDown.Action       = (void *)0;
  EveButton11_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton11_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton11_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton11_OnDown.Sound.Volume = 255;

  EveButton11_OnPress.Action       = save;
  EveButton11_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton11_OnPress.Sound.Effect = _FT800_SOUND_ORGAN;
  EveButton11_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton11_OnPress.Sound.Volume = 255;

  EveButton9.OwnerScreen   = &Screen2;
  EveButton9.Order         = 13;
  EveButton9.Visible       = 1;
  EveButton9.Opacity       = 255;
  EveButton9.Tag           = 255;
  EveButton9.Left          = 396;
  EveButton9.Top           = 228;
  EveButton9.Width         = 80;
  EveButton9.Height        = 40;
  EveButton9.Color         = 0x03DA;
  EveButton9.Press_Color   = 0x7E3F;
  EveButton9.ColorTo       = 0x7E3F;
  EveButton9.Press_ColorTo = 0x03DA;
  EveButton9.Caption       = EveButton9_Caption;
  EveButton9.FontName      = 28;
  EveButton9.Font_Color    = 0x0000;
  EveButton9.FontHandle    = 28;
  EveButton9.Source        = -1UL;
  EveButton9.Flat          = 0;
  EveButton9.Active        = 1;
  EveButton9.OnUp          = 0;
  EveButton9.OnDown        = &EveButton9_OnDown;
  EveButton9.OnClick       = 0;
  EveButton9.OnPress       = &EveButton9_OnPress;

  EveButton9_OnDown.Action       = (void *)0;
  EveButton9_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton9_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton9_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton9_OnDown.Sound.Volume = 255;

  EveButton9_OnPress.Action       = page_3;
  EveButton9_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton9_OnPress.Sound.Effect = _FT800_SOUND_TRUMPET;
  EveButton9_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton9_OnPress.Sound.Volume = 255;

  EveButton10.OwnerScreen   = &Screen2;
  EveButton10.Order         = 14;
  EveButton10.Visible       = 1;
  EveButton10.Opacity       = 255;
  EveButton10.Tag           = 255;
  EveButton10.Left          = 5;
  EveButton10.Top           = 228;
  EveButton10.Width         = 80;
  EveButton10.Height        = 40;
  EveButton10.Color         = 0x03DA;
  EveButton10.Press_Color   = 0x7E3F;
  EveButton10.ColorTo       = 0x7E3F;
  EveButton10.Press_ColorTo = 0x03DA;
  EveButton10.Caption       = EveButton10_Caption;
  EveButton10.FontName      = 29;
  EveButton10.Font_Color    = 0x0000;
  EveButton10.FontHandle    = 29;
  EveButton10.Source        = -1UL;
  EveButton10.Flat          = 0;
  EveButton10.Active        = 1;
  EveButton10.OnUp          = 0;
  EveButton10.OnDown        = &EveButton10_OnDown;
  EveButton10.OnClick       = 0;
  EveButton10.OnPress       = &EveButton10_OnPress;

  EveButton10_OnDown.Action       = (void *)0;
  EveButton10_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton10_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton10_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton10_OnDown.Sound.Volume = 255;

  EveButton10_OnPress.Action       = page_1;
  EveButton10_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton10_OnPress.Sound.Effect = _FT800_SOUND_GLOCKENSPIEL;
  EveButton10_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton10_OnPress.Sound.Volume = 255;

  EveSlider1.OwnerScreen      = &Screen3;
  EveSlider1.Order            = 0;
  EveSlider1.Visible          = 1;
  EveSlider1.Opacity          = 255;
  EveSlider1.Tag              = 255;
  EveSlider1.Left             = 50;
  EveSlider1.Top              = 25;
  EveSlider1.Width            = 400;
  EveSlider1.Height           = 35;
  EveSlider1.Background_Color = 0xC618;
  EveSlider1.Thumb_Color      = 0xF800;
  EveSlider1.Color            = 0xC618;
  EveSlider1.Press_Color      = 0x0000;
  EveSlider1.Value            = 0;
  EveSlider1.Range            = 31;
  EveSlider1.Flat             = 0;
  EveSlider1.Active           = 1;
  EveSlider1.OnUp             = 0;
  EveSlider1.OnDown           = 0;
  EveSlider1.OnClick          = 0;
  EveSlider1.OnPress          = &EveSlider1_OnPress;

  EveSlider1_OnPress.Action       = slider_1;
  EveSlider1_OnPress.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveSlider1_OnPress.Sound.Effect = _FT800_SOUND_CLICK;
  EveSlider1_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveSlider1_OnPress.Sound.Volume = 255;

  EveSlider2.OwnerScreen      = &Screen3;
  EveSlider2.Order            = 1;
  EveSlider2.Visible          = 1;
  EveSlider2.Opacity          = 255;
  EveSlider2.Tag              = 255;
  EveSlider2.Left             = 50;
  EveSlider2.Top              = 100;
  EveSlider2.Width            = 400;
  EveSlider2.Height           = 35;
  EveSlider2.Background_Color = 0xC618;
  EveSlider2.Thumb_Color      = 0x07E0;
  EveSlider2.Color            = 0xC618;
  EveSlider2.Press_Color      = 0x0000;
  EveSlider2.Value            = 0;
  EveSlider2.Range            = 63;
  EveSlider2.Flat             = 0;
  EveSlider2.Active           = 1;
  EveSlider2.OnUp             = 0;
  EveSlider2.OnDown           = 0;
  EveSlider2.OnClick          = 0;
  EveSlider2.OnPress          = &EveSlider2_OnPress;

  EveSlider2_OnPress.Action       = slider_2;
  EveSlider2_OnPress.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveSlider2_OnPress.Sound.Effect = _FT800_SOUND_CLICK;
  EveSlider2_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveSlider2_OnPress.Sound.Volume = 255;

  EveSlider3.OwnerScreen      = &Screen3;
  EveSlider3.Order            = 2;
  EveSlider3.Visible          = 1;
  EveSlider3.Opacity          = 255;
  EveSlider3.Tag              = 255;
  EveSlider3.Left             = 50;
  EveSlider3.Top              = 175;
  EveSlider3.Width            = 400;
  EveSlider3.Height           = 35;
  EveSlider3.Background_Color = 0xC618;
  EveSlider3.Thumb_Color      = 0x041F;
  EveSlider3.Color            = 0xC618;
  EveSlider3.Press_Color      = 0x0000;
  EveSlider3.Value            = 0;
  EveSlider3.Range            = 31;
  EveSlider3.Flat             = 0;
  EveSlider3.Active           = 1;
  EveSlider3.OnUp             = 0;
  EveSlider3.OnDown           = 0;
  EveSlider3.OnClick          = 0;
  EveSlider3.OnPress          = &EveSlider3_OnPress;

  EveSlider3_OnPress.Action       = slider_3;
  EveSlider3_OnPress.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveSlider3_OnPress.Sound.Effect = _FT800_SOUND_CLICK;
  EveSlider3_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveSlider3_OnPress.Sound.Volume = 255;

  EveNumber1.OwnerScreen = &Screen3;
  EveNumber1.Order       = 3;
  EveNumber1.Visible     = 1;
  EveNumber1.Opacity     = 255;
  EveNumber1.Tag         = 255;
  EveNumber1.Left        = 211;
  EveNumber1.Top         = 270;
  EveNumber1.Width       = 8;
  EveNumber1.Height      = 17;
  EveNumber1.Text_Length = 0;
  EveNumber1.TextAlign   = taNone;
  EveNumber1.FontName    = 26;
  EveNumber1.Font_Color  = 0x0000;
  EveNumber1.FontHandle  = 26;
  EveNumber1.Source      = -1UL;
  EveNumber1.Value       = 0;
  EveNumber1.Signed      = 0;
  EveNumber1.Active      = 1;
  EveNumber1.OnUp        = 0;
  EveNumber1.OnDown      = 0;
  EveNumber1.OnClick     = 0;
  EveNumber1.OnPress     = 0;

  EveButton12.OwnerScreen   = &Screen3;
  EveButton12.Order         = 4;
  EveButton12.Visible       = 1;
  EveButton12.Opacity       = 255;
  EveButton12.Tag           = 255;
  EveButton12.Left          = 398;
  EveButton12.Top           = 230;
  EveButton12.Width         = 80;
  EveButton12.Height        = 40;
  EveButton12.Color         = 0x03DA;
  EveButton12.Press_Color   = 0x7E3F;
  EveButton12.ColorTo       = 0x7E3F;
  EveButton12.Press_ColorTo = 0x03DA;
  EveButton12.Caption       = EveButton12_Caption;
  EveButton12.FontName      = 28;
  EveButton12.Font_Color    = 0x0000;
  EveButton12.FontHandle    = 28;
  EveButton12.Source        = -1UL;
  EveButton12.Flat          = 0;
  EveButton12.Active        = 1;
  EveButton12.OnUp          = 0;
  EveButton12.OnDown        = &EveButton12_OnDown;
  EveButton12.OnClick       = 0;
  EveButton12.OnPress       = &EveButton12_OnPress;

  EveButton12_OnDown.Action       = (void *)0;
  EveButton12_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton12_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton12_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton12_OnDown.Sound.Volume = 255;

  EveButton12_OnPress.Action       = page_4;
  EveButton12_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton12_OnPress.Sound.Effect = _FT800_SOUND_TUBA;
  EveButton12_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton12_OnPress.Sound.Volume = 255;

  EveButton13.OwnerScreen   = &Screen3;
  EveButton13.Order         = 5;
  EveButton13.Visible       = 1;
  EveButton13.Opacity       = 255;
  EveButton13.Tag           = 255;
  EveButton13.Left          = 2;
  EveButton13.Top           = 230;
  EveButton13.Width         = 80;
  EveButton13.Height        = 40;
  EveButton13.Color         = 0x03DA;
  EveButton13.Press_Color   = 0x7E3F;
  EveButton13.ColorTo       = 0x7E3F;
  EveButton13.Press_ColorTo = 0x03DA;
  EveButton13.Caption       = EveButton13_Caption;
  EveButton13.FontName      = 28;
  EveButton13.Font_Color    = 0x0000;
  EveButton13.FontHandle    = 28;
  EveButton13.Source        = -1UL;
  EveButton13.Flat          = 0;
  EveButton13.Active        = 1;
  EveButton13.OnUp          = 0;
  EveButton13.OnDown        = &EveButton13_OnDown;
  EveButton13.OnClick       = 0;
  EveButton13.OnPress       = &EveButton13_OnPress;

  EveButton13_OnDown.Action       = (void *)0;
  EveButton13_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton13_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton13_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton13_OnDown.Sound.Volume = 255;

  EveButton13_OnPress.Action       = Page_2;
  EveButton13_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton13_OnPress.Sound.Effect = _FT800_SOUND_XYLOPHONE;
  EveButton13_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton13_OnPress.Sound.Volume = 255;

  EveSketch1.OwnerScreen      = &Screen4;
  EveSketch1.Order            = 0;
  EveSketch1.Visible          = 1;
  EveSketch1.Opacity          = 255;
  EveSketch1.Tag              = 255;
  EveSketch1.Left             = 0;
  EveSketch1.Top              = 0;
  EveSketch1.Width            = 480;
  EveSketch1.Height           = 224;
  EveSketch1.Pen_Width        = 2;
  EveSketch1.Pen_Color        = 0x0000;
  EveSketch1.Draw_Color       = 0xF800;
  EveSketch1.Background_Color = 0xC618;
  EveSketch1.Transparent      = 0;
  EveSketch1.ColorFormat      = _FT800_BITMAP_FORMAT_L1;
  EveSketch1.Clear            = 0;
  EveSketch1.Source           = 0;
  EveSketch1.Active           = 1;
  EveSketch1.OnUp             = 0;
  EveSketch1.OnDown           = &EveSketch1_OnDown;
  EveSketch1.OnClick          = 0;
  EveSketch1.OnPress          = 0;

  EveSketch1_OnDown.Action       = (void *)0;
  EveSketch1_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveSketch1_OnDown.Sound.Effect = _FT800_SOUND_CLICK;
  EveSketch1_OnDown.Sound.Pitch  = 0;
  EveSketch1_OnDown.Sound.Volume = 255;

  EveButton2.OwnerScreen   = &Screen4;
  EveButton2.Order         = 1;
  EveButton2.Visible       = 1;
  EveButton2.Opacity       = 255;
  EveButton2.Tag           = 255;
  EveButton2.Left          = 398;
  EveButton2.Top           = 228;
  EveButton2.Width         = 78;
  EveButton2.Height        = 40;
  EveButton2.Color         = 0x03DA;
  EveButton2.Press_Color   = 0x7E3F;
  EveButton2.ColorTo       = 0x7E3F;
  EveButton2.Press_ColorTo = 0x03DA;
  EveButton2.Caption       = EveButton2_Caption;
  EveButton2.FontName      = 29;
  EveButton2.Font_Color    = 0x0000;
  EveButton2.FontHandle    = 29;
  EveButton2.Source        = -1UL;
  EveButton2.Flat          = 0;
  EveButton2.Active        = 1;
  EveButton2.OnUp          = 0;
  EveButton2.OnDown        = &EveButton2_OnDown;
  EveButton2.OnClick       = 0;
  EveButton2.OnPress       = &EveButton2_OnPress;

  EveButton2_OnDown.Action       = (void *)0;
  EveButton2_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton2_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton2_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton2_OnDown.Sound.Volume = 255;

  EveButton2_OnPress.Action       = page_1;
  EveButton2_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton2_OnPress.Sound.Effect = _FT800_SOUND_TRUMPET;
  EveButton2_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton2_OnPress.Sound.Volume = 255;

  EveButton3.OwnerScreen   = &Screen4;
  EveButton3.Order         = 2;
  EveButton3.Visible       = 1;
  EveButton3.Opacity       = 255;
  EveButton3.Tag           = 255;
  EveButton3.Left          = 200;
  EveButton3.Top           = 228;
  EveButton3.Width         = 68;
  EveButton3.Height        = 40;
  EveButton3.Color         = 0x03DA;
  EveButton3.Press_Color   = 0x7E3F;
  EveButton3.ColorTo       = 0x7E3F;
  EveButton3.Press_ColorTo = 0x03DA;
  EveButton3.Caption       = EveButton3_Caption;
  EveButton3.FontName      = 28;
  EveButton3.Font_Color    = 0x0000;
  EveButton3.FontHandle    = 28;
  EveButton3.Source        = -1UL;
  EveButton3.Flat          = 0;
  EveButton3.Active        = 1;
  EveButton3.OnUp          = 0;
  EveButton3.OnDown        = &EveButton3_OnDown;
  EveButton3.OnClick       = 0;
  EveButton3.OnPress       = &EveButton3_OnPress;

  EveButton3_OnDown.Action       = (void *)0;
  EveButton3_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton3_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton3_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton3_OnDown.Sound.Volume = 255;

  EveButton3_OnPress.Action       = clear;
  EveButton3_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton3_OnPress.Sound.Effect = _FT800_SOUND_XYLOPHONE;
  EveButton3_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_F5;
  EveButton3_OnPress.Sound.Volume = 255;

  EveButton14.OwnerScreen   = &Screen4;
  EveButton14.Order         = 3;
  EveButton14.Visible       = 1;
  EveButton14.Opacity       = 255;
  EveButton14.Tag           = 255;
  EveButton14.Left          = 4;
  EveButton14.Top           = 228;
  EveButton14.Width         = 78;
  EveButton14.Height        = 40;
  EveButton14.Color         = 0x03DA;
  EveButton14.Press_Color   = 0x7E3F;
  EveButton14.ColorTo       = 0x7E3F;
  EveButton14.Press_ColorTo = 0x03DA;
  EveButton14.Caption       = EveButton14_Caption;
  EveButton14.FontName      = 29;
  EveButton14.Font_Color    = 0x0000;
  EveButton14.FontHandle    = 29;
  EveButton14.Source        = -1UL;
  EveButton14.Flat          = 0;
  EveButton14.Active        = 1;
  EveButton14.OnUp          = 0;
  EveButton14.OnDown        = &EveButton14_OnDown;
  EveButton14.OnClick       = 0;
  EveButton14.OnPress       = &EveButton14_OnPress;

  EveButton14_OnDown.Action       = (void *)0;
  EveButton14_OnDown.Sound.SndAct = VTFT_SNDACT_PLAY;
  EveButton14_OnDown.Sound.Effect = _FT800_SOUND_HARP;
  EveButton14_OnDown.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton14_OnDown.Sound.Volume = 255;

  EveButton14_OnPress.Action       = page_3;
  EveButton14_OnPress.Sound.SndAct = VTFT_SNDACT_NONE;
  EveButton14_OnPress.Sound.Effect = _FT800_SOUND_TRUMPET;
  EveButton14_OnPress.Sound.Pitch  = _FT800_SOUND_PITCH_A5;
  EveButton14_OnPress.Sound.Volume = 255;

}

void Init_MCU() {
SPI1_Init_Advanced(_SPI_MASTER_OSC_DIV4, _SPI_DATA_SAMPLE_MIDDLE,
                       _SPI_CLK_IDLE_LOW, _SPI_LOW_2_HIGH); 
}

void InitVTFTStack() {
  union {
    TFT800PWM       PWM;
    TFT800GPIO      GPIO;
    TFT800Audio     Audio;
    TFT800Sound     Sound;
    TFT800Touch     Touch;
    TFT800Display   Display;
    TFT800Interrupt Interrupt;
  } cfg;

  Init_MCU();

  SPI_Set_Active(SPI1_Read, SPI1_Write);

  // Init all dynamic objects
  InitObjects();

  // Init FT800 controller core and library stack
  FT800_Init();

  FT800_Core_ClockSource(_FT800_CLK_SOURCE_EXTERNAL);
  FT800_Core_ClockPLL(_FT800_CLK_PLL_48MHz);

  // Internal modules setup
  cfg.Display = VTFT_FT800_CONFIG_DISPLAY;
  FT800_Display_SetConfig(&cfg.Display);

  cfg.Audio = VTFT_FT800_CONFIG_AUDIO;
  FT800_Audio_SetConfig(&cfg.Audio);

  cfg.Sound = VTFT_FT800_CONFIG_SOUND;
  FT800_Sound_SetConfig(&cfg.Sound);

  cfg.Interrupt = VTFT_FT800_CONFIG_INTERRUPT;
  FT800_Interrupt_SetConfig(&cfg.Interrupt);

  cfg.PWM = VTFT_FT800_CONFIG_PWM;
  FT800_PWM_SetConfig(&cfg.PWM);

  cfg.GPIO = VTFT_FT800_CONFIG_GPIO;
  FT800_GPIO_SetConfig(&cfg.GPIO);

  cfg.Touch = VTFT_FT800_CONFIG_TOUCH;
  FT800_Touch_SetConfig(&cfg.Touch);

  FT800_Touch_Calibrate(_FT800_FONT_ROBOTO_SIZE_10, "Touch blinking point on the screen!");

  // Draw start screen
  DrawScreen(&Screen1);
}
