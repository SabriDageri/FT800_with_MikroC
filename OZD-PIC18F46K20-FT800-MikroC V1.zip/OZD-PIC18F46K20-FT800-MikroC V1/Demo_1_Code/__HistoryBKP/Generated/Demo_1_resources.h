#ifndef DEMO_1_RESOURCES
#define DEMO_1_RESOURCES


#endif
