#ifndef DEMO_1_OBJECTS
#define DEMO_1_OBJECTS

#include "FT800_Types.h"

typedef enum {taNone, taLeft, taCenter, taRight, taCenterX, taCenterY, taRightX} TTextAlign;

typedef struct Screen TScreen;

typedef unsigned long TPointer;

typedef struct tagObjInfo {
  void     *Obj;
  char     Type;
  char     Order;
  char     Flags;

  char     HitTag;
  int      HitX;
  int      HitY;
} TObjInfo;

typedef struct tagTouchStat {
  char Pressed;

  char Tag;
  int  X;
  int  Y;

  TObjInfo ActObjInfo;
} TTouchStat;

typedef void (*TDrawHandler)(TPointer aObj);

typedef void (*TEvtAction)();

typedef struct tagEvtSound {
  char SndAct;
  char Effect;
  char Pitch;
  char Volume;
} TEvtSound;

typedef const struct tagCEvent {
  TEvtAction Action;
  TEvtSound  Sound;
} TCEvent;

typedef struct tagEvent {
  TEvtAction Action;
  TEvtSound  Sound;
} TEvent;

typedef const struct tagCRect {
  int Left;
  int Top;
  int Width;
  int Height;
} TCRect;

typedef struct tagRect {
  int Left;
  int Top;
  int Width;
  int Height;
} TRect;

typedef struct tagLabel {
  TScreen         *OwnerScreen;
  char            Order;
  char            Visible;
  char            Opacity;
  char            Tag;
  int             Left;
  int             Top;
  int             Width;
  int             Height;
  char            *Caption;
  const code char *FontName;
  unsigned int    Font_Color;
  char            FontHandle;
  long            Source;
  char            Active;
  TEvent          *OnUp;
  TEvent          *OnDown;
  TEvent          *OnClick;
  TEvent          *OnPress;
} TLabel;

typedef struct tagEveClock {
  TScreen      *OwnerScreen;
  char         Order;
  char         Visible;
  char         Opacity;
  char         Tag;
  int          Left;
  int          Top;
  int          Radius;
  char         Pen_Width;
  unsigned int Pen_Color;
  unsigned int Color;
  unsigned int Press_Color;
  char         Hour;
  char         Min;
  char         Sec;
  char         Flat;
  char         NoBackground;
  char         HandsVisible;
  char         SecsVisible;
  char         TicksVisible;
  char         Active;
  TEvent       *OnUp;
  TEvent       *OnDown;
  TEvent       *OnClick;
  TEvent       *OnPress;
} TEveClock;

typedef struct tagEveGauge {
  TScreen      *OwnerScreen;
  char         Order;
  char         Visible;
  char         Opacity;
  char         Tag;
  int          Left;
  int          Top;
  int          Radius;
  char         Pen_Width;
  unsigned int Pen_Color;
  unsigned int Color;
  unsigned int Press_Color;
  char         Major;
  char         Minor;
  unsigned int Value;
  unsigned int Range;
  char         Flat;
  char         NoBackground;
  char         NoPointer;
  char         TicksVisible;
  char         Active;
  TEvent       *OnUp;
  TEvent       *OnDown;
  TEvent       *OnClick;
  TEvent       *OnPress;
} TEveGauge;

typedef struct tagEveKeys {
  TScreen         *OwnerScreen;
  char            Order;
  char            Visible;
  char            Opacity;
  char            Tag;
  int             Left;
  int             Top;
  int             Width;
  int             Height;
  unsigned int    Color;
  unsigned int    Press_Color;
  unsigned int    ColorTo;
  unsigned int    Press_ColorTo;
  char            *Caption;
  const code char *FontName;
  unsigned int    Font_Color;
  char            FontHandle;
  long            Source;
  char            Flat;
  char            AutoSize;
  char            Active;
  TEvent          *OnUp;
  TEvent          *OnDown;
  TEvent          *OnClick;
  TEvent          *OnPress;
} TEveKeys;

typedef struct tagEveSlider {
  TScreen      *OwnerScreen;
  char         Order;
  char         Visible;
  char         Opacity;
  char         Tag;
  int          Left;
  int          Top;
  int          Width;
  int          Height;
  unsigned int Background_Color;
  unsigned int Thumb_Color;
  unsigned int Color;
  unsigned int Press_Color;
  unsigned int Value;
  unsigned int Range;
  char         Flat;
  char         Active;
  TEvent       *OnUp;
  TEvent       *OnDown;
  TEvent       *OnClick;
  TEvent       *OnPress;
} TEveSlider;

typedef struct tagEveSpinner {
  TScreen      *OwnerScreen;
  char         Tag;
  int          Left;
  int          Top;
  unsigned int Color;
  char         Style;
  char         Scale;
} TEveSpinner;

typedef struct tagEveSketch {
  TScreen      *OwnerScreen;
  char         Order;
  char         Visible;
  char         Opacity;
  char         Tag;
  int          Left;
  int          Top;
  int          Width;
  int          Height;
  char         Pen_Width;
  unsigned int Pen_Color;
  unsigned int Draw_Color;
  unsigned int Background_Color;
  char         Transparent;
  char         ColorFormat;
  char         Clear;
  long         Source;
  char         Active;
  TEvent       *OnUp;
  TEvent       *OnDown;
  TEvent       *OnClick;
  TEvent       *OnPress;
} TEveSketch;

typedef struct tagEveButton {
  TScreen         *OwnerScreen;
  char            Order;
  char            Visible;
  char            Opacity;
  char            Tag;
  int             Left;
  int             Top;
  int             Width;
  int             Height;
  unsigned int    Color;
  unsigned int    Press_Color;
  unsigned int    ColorTo;
  unsigned int    Press_ColorTo;
  char            *Caption;
  const code char *FontName;
  unsigned int    Font_Color;
  char            FontHandle;
  long            Source;
  char            Flat;
  char            Active;
  TEvent          *OnUp;
  TEvent          *OnDown;
  TEvent          *OnClick;
  TEvent          *OnPress;
} TEveButton;

typedef struct tagEveNumber {
  TScreen         *OwnerScreen;
  char            Order;
  char            Visible;
  char            Opacity;
  char            Tag;
  int             Left;
  int             Top;
  int             Width;
  int             Height;
  char            Text_Length;
  TTextAlign      TextAlign;
  const code char *FontName;
  unsigned int    Font_Color;
  char            FontHandle;
  long            Source;
  signed long     Value;
  unsigned char   Signed;
  char            Active;
  TEvent          *OnUp;
  TEvent          *OnDown;
  TEvent          *OnClick;
  TEvent          *OnPress;
} TEveNumber;

struct Screen {
  unsigned int   Color;
  unsigned int   Width;
  unsigned int   Height;
  unsigned short ObjectsCount;
  unsigned short LabelsCount;
  TLabel         *const code *Labels;
  unsigned short EveClocksCount;
  TEveClock      *const code *EveClocks;
  unsigned short EveGaugesCount;
  TEveGauge      *const code *EveGauges;
  unsigned short EveKeysCount;
  TEveKeys       *const code *EveKeys;
  unsigned short EveSlidersCount;
  TEveSlider     *const code *EveSliders;
  unsigned short EveSpinnersCount;
  TEveSpinner    *const code *EveSpinners;
  unsigned short EveSketchesCount;
  TEveSketch     *const code *EveSketches;
  unsigned short EveButtonsCount;
  TEveButton     *const code *EveButtons;
  unsigned short EveNumbersCount;
  TEveNumber     *const code *EveNumbers;
  unsigned long  DynResStart;
  unsigned short Active;
  unsigned short **EveAnimation;
  unsigned short SniffObjectEvents;
  TEvent         *OnUp;
  TEvent         *OnDown;
  TEvent         *OnTagChange;
  TEvent         *OnPress;
};


// Object type constants
// Usage: VTFT stack internally
extern const VTFT_OT_LABEL;
extern const VTFT_OT_EVECLOCK;
extern const VTFT_OT_EVEGAUGE;
extern const VTFT_OT_EVEKEYS;
extern const VTFT_OT_EVESLIDER;
extern const VTFT_OT_EVESKETCH;
extern const VTFT_OT_EVEBUTTON;
extern const VTFT_OT_EVENUMBER;
// ~Object type constants

// Event type constants
// Usage: OnEvent
extern const VTFT_EVT_UP;
extern const VTFT_EVT_DOWN;
extern const VTFT_EVT_CLICK;
extern const VTFT_EVT_PRESS;
// ~Event type constants

// Sound action constants
// Usage: sound event action property and ProcessEvent
extern const VTFT_SNDACT_NONE;
extern const VTFT_SNDACT_PLAY;
extern const VTFT_SNDACT_STOP;
// ~Sound action constants

// Resource loading constants.
// Usage: DrawScreenO and LoadCurrentScreenResToGRAM
extern const VTFT_LOAD_RES_NONE;
extern const VTFT_LOAD_RES_STATIC;
extern const VTFT_LOAD_RES_DYNAMIC;
extern const VTFT_LOAD_RES_ALL;
// ~Resource loading constants

// Display effect constants
// Usage: DrawScreenO
extern const VTFT_DISPLAY_EFF_NONE;
extern const VTFT_DISPLAY_EFF_LIGHTS_FADE;
extern const VTFT_DISPLAY_EFF_LIGHTS_OFF;
// ~Display effect constants

// Stack flags
// Usage: internally used by VTFT stack
extern const VTFT_INT_REPAINT_ON_DOWN;
extern const VTFT_INT_REPAINT_ON_UP;
extern const VTFT_INT_BRING_TO_FRONT;
extern const VTFT_INT_INTRINSIC_CLICK_EFF;
// ~Stack flags

extern const TPointer DrawHandlerTable[44];

// Table of animations
extern void *ScreensEveAnimationTable[4];
// ~Table of animations


// Default configuration parameters
extern const TFT800PWM            VTFT_FT800_CONFIG_PWM;
extern const TFT800GPIO           VTFT_FT800_CONFIG_GPIO;
extern const TFT800Sound          VTFT_FT800_CONFIG_SOUND;
extern const TFT800Audio          VTFT_FT800_CONFIG_AUDIO;
extern const TFT800Display        VTFT_FT800_CONFIG_DISPLAY;
extern const TFT800Interrupt      VTFT_FT800_CONFIG_INTERRUPT;
extern const TFT800Touch          VTFT_FT800_CONFIG_TOUCH;

extern TTouchStat TouchS;

extern TScreen Screen1;

extern TEveClock   EveClock1;
extern TEvent      EveClock1_OnPress;
extern TEveButton  EveButton1;
extern TEvent      EveButton1_OnDown;
extern TEvent      EveButton1_OnPress;
extern TEveNumber  EveNumber2;
extern TEveNumber  EveNumber3;
extern TEveNumber  EveNumber4;
extern TEveGauge   EveGauge1;
extern TEvent      EveGauge1_OnUp;
extern TEvent      EveGauge1_OnDown;
extern TLabel      Label2;
extern TLabel      Label3;
extern TEveNumber  EveNumber10;
extern TLabel      Label4;
extern TLabel      Label5;
extern TEveSpinner EveSpinner1;

extern TLabel      *const code Screen1_Labels[4];
extern TEveClock   *const code Screen1_EveClocks[1];
extern TEveGauge   *const code Screen1_EveGauges[1];
extern TEveSpinner *const code Screen1_EveSpinners[1];
extern TEveButton  *const code Screen1_EveButtons[1];
extern TEveNumber  *const code Screen1_EveNumbers[4];

extern TScreen Screen2;

extern TLabel     Label1;
extern TEveButton EveButton4;
extern TEvent     EveButton4_OnDown;
extern TEvent     EveButton4_OnPress;
extern TEveButton EveButton5;
extern TEvent     EveButton5_OnDown;
extern TEvent     EveButton5_OnPress;
extern TEveButton EveButton6;
extern TEvent     EveButton6_OnDown;
extern TEvent     EveButton6_OnPress;
extern TEveButton EveButton7;
extern TEvent     EveButton7_OnDown;
extern TEvent     EveButton7_OnPress;
extern TEveButton EveButton8;
extern TEvent     EveButton8_OnDown;
extern TEvent     EveButton8_OnPress;
extern TEveKeys   EveKeys1;
extern TEvent     EveKeys1_OnDown;
extern TEvent     EveKeys1_OnPress;
extern TEveNumber EveNumber5;
extern TEveNumber EveNumber6;
extern TEveNumber EveNumber7;
extern TEveNumber EveNumber8;
extern TEveNumber EveNumber9;
extern TEveButton EveButton11;
extern TEvent     EveButton11_OnDown;
extern TEvent     EveButton11_OnPress;
extern TEveButton EveButton9;
extern TEvent     EveButton9_OnDown;
extern TEvent     EveButton9_OnPress;
extern TEveButton EveButton10;
extern TEvent     EveButton10_OnDown;
extern TEvent     EveButton10_OnPress;

extern TLabel     *const code Screen2_Labels[1];
extern TEveKeys   *const code Screen2_EveKeys[1];
extern TEveButton *const code Screen2_EveButtons[8];
extern TEveNumber *const code Screen2_EveNumbers[5];

extern TScreen Screen3;

extern TEveSlider EveSlider1;
extern TEvent     EveSlider1_OnPress;
extern TEveSlider EveSlider2;
extern TEvent     EveSlider2_OnPress;
extern TEveSlider EveSlider3;
extern TEvent     EveSlider3_OnPress;
extern TEveNumber EveNumber1;
extern TEveButton EveButton12;
extern TEvent     EveButton12_OnDown;
extern TEvent     EveButton12_OnPress;
extern TEveButton EveButton13;
extern TEvent     EveButton13_OnDown;
extern TEvent     EveButton13_OnPress;

extern TEveSlider *const code Screen3_EveSliders[3];
extern TEveButton *const code Screen3_EveButtons[2];
extern TEveNumber *const code Screen3_EveNumbers[1];

extern TScreen Screen4;

extern TEveSketch EveSketch1;
extern TEvent     EveSketch1_OnDown;
extern TEveButton EveButton2;
extern TEvent     EveButton2_OnDown;
extern TEvent     EveButton2_OnPress;
extern TEveButton EveButton3;
extern TEvent     EveButton3_OnDown;
extern TEvent     EveButton3_OnPress;
extern TEveButton EveButton14;
extern TEvent     EveButton14_OnDown;
extern TEvent     EveButton14_OnPress;

extern TEveSketch *const code Screen4_EveSketches[1];
extern TEveButton *const code Screen4_EveButtons[3];

extern TScreen *CurrentScreen;

/////////////////////////
// User Event Handlers
void clear();
void Day();
void Hour();
void init_DS1307();
void keypad();
void minute();
void Mount();
void page_1();
void Page_2();
void page_3();
void Page_4();
void save();
void screen_color();
void slider_1();
void slider_2();
void slider_3();
void year();
/////////////////////////

/////////////////////////////////
// Captions
extern char EveButton1_Caption[];
extern char Label2_Caption[];
extern char Label3_Caption[];
extern char Label4_Caption[];
extern char Label5_Caption[];
extern char Label1_Caption[];
extern char EveButton4_Caption[];
extern char EveButton5_Caption[];
extern char EveButton6_Caption[];
extern char EveButton7_Caption[];
extern char EveButton8_Caption[];
extern char EveKeys1_Caption[];
extern char EveButton11_Caption[];
extern char EveButton9_Caption[];
extern char EveButton10_Caption[];
extern char EveButton12_Caption[];
extern char EveButton13_Caption[];
extern char EveButton2_Caption[];
extern char EveButton3_Caption[];
extern char EveButton14_Caption[];

/////////////////////////////////
// Event Descriptors 
extern TEvent EveClock1_OnUpOnPress;
extern TEvent EveButton1_OnUpOnDown;
extern TEvent EveButton1_OnUpOnPress;
extern TEvent EveGauge1_OnUpOnUp;
extern TEvent EveGauge1_OnUpOnDown;
extern TEvent EveButton4_OnUpOnDown;
extern TEvent EveButton4_OnUpOnPress;
extern TEvent EveButton5_OnUpOnDown;
extern TEvent EveButton5_OnUpOnPress;
extern TEvent EveButton6_OnUpOnDown;
extern TEvent EveButton6_OnUpOnPress;
extern TEvent EveButton7_OnUpOnDown;
extern TEvent EveButton7_OnUpOnPress;
extern TEvent EveButton8_OnUpOnDown;
extern TEvent EveButton8_OnUpOnPress;
extern TEvent EveKeys1_OnUpOnDown;
extern TEvent EveKeys1_OnUpOnPress;
extern TEvent EveButton11_OnUpOnDown;
extern TEvent EveButton11_OnUpOnPress;
extern TEvent EveButton9_OnUpOnDown;
extern TEvent EveButton9_OnUpOnPress;
extern TEvent EveButton10_OnUpOnDown;
extern TEvent EveButton10_OnUpOnPress;
extern TEvent EveSlider1_OnUpOnPress;
extern TEvent EveSlider2_OnUpOnPress;
extern TEvent EveSlider3_OnUpOnPress;
extern TEvent EveButton12_OnUpOnDown;
extern TEvent EveButton12_OnUpOnPress;
extern TEvent EveButton13_OnUpOnDown;
extern TEvent EveButton13_OnUpOnPress;
extern TEvent EveSketch1_OnUpOnDown;
extern TEvent EveButton2_OnUpOnDown;
extern TEvent EveButton2_OnUpOnPress;
extern TEvent EveButton3_OnUpOnDown;
extern TEvent EveButton3_OnUpOnPress;
extern TEvent EveButton14_OnUpOnDown;
extern TEvent EveButton14_OnUpOnPress;
/////////////////////////////////

void DrawScreenO(TScreen *aScreen, char aOptions);
void DrawScreen(TScreen *aScreen);
void DisableEveAnimation(TScreen *AScreen);
void EnableEveAnimation(TScreen *AScreen, void * AEveAnimation);
void GetEveSketchBmpCfg(TEveSketch *AEveSketch, int *xPos, int *yPos, TFT800BmpConfig *bmpCfg);
void DrawLabel(TLabel *ALabel);
void DrawEveClock(TEveClock *AEveClock);
void DrawEveGauge(TEveGauge *AEveGauge);
void DrawEveKeys(TEveKeys *AEveKeys);
void DrawEveSlider(TEveSlider *AEveSlider);
char DrawEveSpinner(TEveSpinner *AEveSpinner);
void DrawEveSketch(TEveSketch *AEveSketch);
void DrawEveButton(TEveButton *AEveButton);
void DrawEveNumber(TEveNumber *AEveNumber);
void ProcessVTFTStack();
void InitVTFTStack();

#endif
