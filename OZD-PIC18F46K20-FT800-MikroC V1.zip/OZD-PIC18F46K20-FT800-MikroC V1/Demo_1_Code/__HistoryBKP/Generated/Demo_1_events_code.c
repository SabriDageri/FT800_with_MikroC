#include "Demo_1_objects.h"
#include "Demo_1_resources.h"

//--------------------- User code ---------------------//

//----------------- End of User code ------------------//

// Event Handlers

unsigned long screen_red=0;
unsigned long screen_green=0;
unsigned long screen_blue=0;

unsigned int key_touch=0;

unsigned char key_number=0;

unsigned char select_number=0;

unsigned char select_decate=0;

void screen_color()
{

    Screen1.Color             = screen_red|screen_green|screen_blue;
    Screen3.Color             = screen_red|screen_green|screen_blue;
    DrawScreen(&Screen3);

}

void slider_1() {
   if (TouchS.X < EveSlider1.Left)
    EveSlider1.value = 0;
  else if (TouchS.X > EveSlider1.Left + EveSlider1.Width)
    EveSlider1.value = EveSlider1.Range;
  else
    EveSlider1.value = ((long)(TouchS.X - EveSlider1.Left) * EveSlider1.Range) / EveSlider1.Width;
    screen_red=EveSlider1.value<<11;
    screen_color();
}

void slider_2() {
  if (TouchS.X < EveSlider2.Left)
    EveSlider2.value = 0;
  else if (TouchS.X > EveSlider2.Left + EveSlider2.Width)
    EveSlider2.value = EveSlider2.Range;
  else
    EveSlider2.value = ((long)(TouchS.X - EveSlider2.Left) * EveSlider2.Range) / EveSlider2.Width;
    screen_green=EveSlider2.value<<5;
    screen_color();
}

void slider_3() {
   if (TouchS.X < EveSlider3.Left)
    EveSlider3.value = 0;
  else if (TouchS.X > EveSlider3.Left + EveSlider3.Width)
    EveSlider3.value = EveSlider3.Range;
  else
    EveSlider3.value = ((long)(TouchS.X - EveSlider3.Left) * EveSlider3.Range) / EveSlider3.Width;
    screen_blue=EveSlider3.value;
    screen_color();
}

void init_DS1307(unsigned char set_min,unsigned char set_hour,unsigned char set_day,unsigned char set_mount,unsigned char set_year)
{
  unsigned int temp_1=0;
  unsigned int temp_2=0;

  temp_1= (set_min/10);
  temp_2= set_min-(temp_1*10);
  set_min= (temp_1<<4)|temp_2;

  temp_1= (set_hour/10);
  temp_2= set_hour-(temp_1*10);
  set_hour= (temp_1<<4)|temp_2;

  temp_1= (set_day/10);
  temp_2= set_day-(temp_1*10);
  set_day= (temp_1<<4)|temp_2;

  temp_1= (set_mount/10);
  temp_2= set_mount-(temp_1*10);
  set_mount= (temp_1<<4)|temp_2;

  temp_1= (set_year/10);
  temp_2= set_year-(temp_1*10);
  set_year= (temp_1<<4)|temp_2;

  Soft_I2C_Start();
  Soft_I2C_Write(0xD0);
  Soft_I2C_Write(0);
  Soft_I2C_Write(0x00);             //second
  Soft_I2C_Write(set_min);             //minute
  Soft_I2C_Write(set_hour);              //hours
  Soft_I2C_Write(0x00);       //week days
  Soft_I2C_Write(set_day);        //mount days
  Soft_I2C_Write(set_mount);      //mounth
  Soft_I2C_Write(set_year);       //year

  Soft_I2C_Write(0x07);       //ctrl reg
  Soft_I2C_Write(0x80);      //disable sq wave
  Soft_I2C_Stop();

  Soft_I2C_Init();           // Initialize Soft I2C communication
  Soft_I2C_Start();                 // issue start signal
  Soft_I2C_Write(0xD0);         // address of ds1307
  Soft_I2C_Write(0);              // start from word at address 0
  //Soft_I2C_Write(0);              // write 0 to config word (enable counting)
  Soft_I2C_Stop();
}


void save() 
{

   init_DS1307(EveNumber5.Value,EveNumber6.Value,EveNumber7.Value,EveNumber8.Value,EveNumber9.Value);
   DrawScreen(&Screen1);
}

void Page_2() {
    EveNumber5.Value=eveclock1.min;
    EveNumber6.Value=eveclock1.hour;
    EveNumber7.Value=EveNumber2.Value;
    EveNumber8.Value=EveNumber3.Value;
    EveNumber9.Value=EveNumber4.Value-2000;
    select_number=1;
    select_decate=0;
    EveNumber5.Font_Color=0xF800;
    EveNumber6.Font_Color=0;
    EveNumber7.Font_Color=0;
    EveNumber8.Font_Color=0;
    EveNumber9.Font_Color=0;
    DrawScreen(&Screen2);
}

void page_3() {
   DrawScreen(&Screen3);
}

void Page_4() {
    DrawScreen(&Screen4);
}


void clear() {
     EveSketch1.clear=1;
}

void minute() {
  select_number=1;
  select_decate=0;
  EveNumber5.Font_Color=0xF800;
  EveNumber6.Font_Color=0;
  EveNumber7.Font_Color=0;
  EveNumber8.Font_Color=0;
  EveNumber9.Font_Color=0;
}

void Hour() {
  select_number=2;
  select_decate=0;
  EveNumber5.Font_Color=0;
  EveNumber6.Font_Color=0xF800;
  EveNumber7.Font_Color=0;
  EveNumber8.Font_Color=0;
  EveNumber9.Font_Color=0;
}

void Day() {
  select_number=3;
  select_decate=0;
  EveNumber5.Font_Color=0;
  EveNumber6.Font_Color=0;
  EveNumber7.Font_Color=0xF800;
  EveNumber8.Font_Color=0;
  EveNumber9.Font_Color=0;
}

void Mount() {
  select_number=4;
  select_decate=0;
  EveNumber5.Font_Color=0;
  EveNumber6.Font_Color=0;
  EveNumber7.Font_Color=0;
  EveNumber8.Font_Color=0xF800;
  EveNumber9.Font_Color=0;
}

void year() {
  select_number=5;
  select_decate=0;
  EveNumber5.Font_Color=0;
  EveNumber6.Font_Color=0;
  EveNumber7.Font_Color=0;
  EveNumber8.Font_Color=0;
  EveNumber9.Font_Color=0xF800;
}

void keypad() {
    if (TouchS.X < EveKeys1.Left)
    key_touch = 0;
  else if (TouchS.X > EveKeys1.Left + EveKeys1.Width)
    key_touch = EveKeys1.width;
  else
    key_touch = TouchS.X-EveKeys1.Left;
    
    key_number= (key_touch*10)/470;
    
    switch (select_number)
    {
       case 1:
         if(select_decate==0)
         {
             select_decate=1;
             EveNumber5.Value=key_number;
         }
         else
         {
             select_decate=0;
             EveNumber5.Value=(EveNumber5.Value*10)+key_number;
         }
         if(EveNumber5.Value>59)
         {
             EveNumber5.Value=59;
         }
       break;
       case 2:
         if(select_decate==0)
         {
             select_decate=1;
             EveNumber6.Value=key_number;
         }
         else
         {
             select_decate=0;
             EveNumber6.Value=(EveNumber6.Value*10)+key_number;
         }
         if(EveNumber6.Value>23)
         {
             EveNumber6.Value=23;
         }
       break;
       case 3:
         if(select_decate==0)
         {
             select_decate=1;
             EveNumber7.Value=key_number;
         }
         else
         {
             select_decate=0;
             EveNumber7.Value=(EveNumber7.Value*10)+key_number;
         }
         if(EveNumber7.Value>31)
         {
             EveNumber7.Value=31;
         }
       break;
       case 4:
         if(select_decate==0)
         {
             select_decate=1;
             EveNumber8.Value=key_number;
         }
         else
         {
             select_decate=0;
             EveNumber8.Value=(EveNumber8.Value*10)+key_number;
         }
         if(EveNumber8.Value>12)
         {
             EveNumber8.Value=12;
         }
       break;
       case 5:
         if(select_decate==0)
         {
             select_decate=1;
             EveNumber9.Value=key_number;
         }
         else
         {
             select_decate=0;
             EveNumber9.Value=(EveNumber9.Value*10)+key_number;
         }
       break;
    }
}

void page_1() {
   DrawScreen(&Screen1);
}
